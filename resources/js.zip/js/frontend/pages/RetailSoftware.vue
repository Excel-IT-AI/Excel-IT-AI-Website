<template>
    <!-- industries top title section start -->
    <section class="trasnport mt-5" style="padding: 50px 0px 50px 0px">
        <div class="container">
            <div class="row" style="text-align: center; padding-bottom: 50px">
                <h2 class="global-title">
                    <span class="rounded">Retail software </span>
                </h2>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <br />
                    <p
                        style="
                            text-align: justify;
                            color: white;
                            word-spacing: 0.2ch;
                            text-transform: capitalize;
                            line-height: 25px;
                        "
                    >
                        Our team develops retail software to empower
                        brick-and-mortars to compete with ecommerce platforms.
                        We give retailers the tools for providing seamless
                        customer experience and personalized service across
                        various channels, be it in- or near-store, web, or
                        mobile.
                    </p>
                </div>
                <div class="col-md-2"></div>
                <div class="col-md-4" data-aos="fade-left">
                    <IndustriesLink></IndustriesLink>
                </div>
            </div>
        </div>
    </section>
    <!-- industries top title section end -->

    <!-- start of title content row  -->
    <div class="container row my-5">
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Retail app development
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                Itransition develops custom retail software from scratch or
                based on industry-leading platforms (SAP Commerce Cloud, Magento
                Commerce, and more) that connect online and offline channels and
                help your retail business reach digitally savvy customers.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Full-range integration
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                We connect retail apps with enterprise systems, such as ERPs,
                supply chain management systems, ecommerce modules, and legacy
                systems to make sure you have a hub for controlling and managing
                a range of retail operations end to end.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                In-store automation
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                We deploy in-store automation so that you could leverage
                sensors, beacons, and mobile apps to create connected, digitally
                augmented experiences for your visitors, increase store
                usability, and boost operational efficiency.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                BI and data analytics
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                Itransition’s team constructs BI infrastructures that process
                structured and unstructured data from different channels. These
                provide insights on customer behavior and preferences, stock
                movement and demand, shop-floor usability, and other critical
                metrics.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                End-to-end retail software development
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                We develop complex multifunctional systems and standalone
                modules for specific operations, based on proven retail
                technologies. We further integrate them into corporate
                infrastructures, seeing to every retail stage and streamlining
                critical yet often manual and routine processes.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                POS development
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                We develop POS software that will turn your terminals into a key
                point in the customer experience continuum. We connect POS to
                inventory systems to give your staff access to product
                information and availability in real time, as well as to your
                CRM to access customers’ purchase and loyalty records. Our POS
                software will ensure fast and secure payment processing.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Inventory and pricing
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                We create and upgrade inventory management systems to provide
                inventory and pricing visibility across retail outlets, digital
                sales channels, and warehouses. By leveraging analytics and
                reporting, you will be able to manage prices and discounts, come
                up with effective merchandising strategies, and track product
                shelf life and stock levels.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Order fulfillment
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                Our team creates digital fulfillment solutions to automate order
                tracking, shipping, and delivery management. They can streamline
                click-and-collect, track order statuses across online and
                offline channels, and automate invoice and receipt generation.
                Such a solution can also serve as a collaboration portal for
                assistants, fulfillment managers, and couriers.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Billing and payments
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                We build and integrate custom solutions to streamline billing,
                cut processing delays, and speed up checkout and refunds. Our
                solutions support multiple payment options, including via mobile
                and wearables. We also provide smooth payment experience for
                self-checkout stations. We make sure all the transactions are
                secure and tamper-proof.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Marketing automation
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                We enable marketing automation to facilitate personalized
                engagement of your customers. Your retail solution will build up
                customer segments and profiles based on multi-source data,
                analyze trends and patterns, and help you personalize your ad,
                email and social media campaigns, promotions, and beacon
                notifications based on the customer’s location, preferences, and
                purchase history.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Ecommerce development
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                Itransition builds and optimizes online commerce platforms to
                serve connected customers wherever they choose to make a
                purchase, seek help, or make a return. We create trade portals,
                online stores, B2B or B2C marketplaces, and modules for shopping
                on social media, equipped with secure and fast e-payment tools
                and support options, such as call centers and AI-based chatbots.
            </p>
        </div>
    </div>
    <!-- end of title content row  -->

    <!--custom software  part start -->
    <section class="web_offer" style="font-family: sens-serif">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 mt-4 mb-4">
                    <h2
                        class="text-center global-title"
                        style="font-family: sens-serif"
                    >
                        <span class="rounded">
                            Our retail software development process
                        </span>
                    </h2>
                </div>
                <div class="col-sm-12 mt-4 mb-4">
                    <p style="color: #215670; text-transform: capitalize">
                        At Excel IT AI, we strictly keep up with project
                        deadlines and always try to minimize development costs
                        where possible. This is achieved through the following
                        steps, which are a necessary part of our real estate
                        software services.
                    </p>
                </div>
            </div>
        </div>
    </section>
    <!-- custom software part end -->

    <!-- ======= nine different sections Section ======= -->
    <section id="why-us" class="why-us section-bg px-5 py-5">
        <div class="container-fluid">
            <!-- first ROW strat -->
            <div class="row">
                <div class="col-md-4">
                    <div class="row">
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class="img-1st"
                                    src="../../../assets/img/bigdata.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <img
                                    src="../../../assets/img/border-1.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <div class="img-2nd center">
                                    <span>01</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class=""
                                    src="../../../assets/img/arrow-1.png"
                                    alt="Avatar"
                                />
                            </div>
                        </div>

                        <div class="content-box">
                            <h4 class="center">
                                <a href="" style="color: #92e3a9"
                                    >Business Analysis
                                </a>
                            </h4>
                            <p>
                                We always conduct end-to-end market research at
                                the early stage of custom retail software
                                development to determine the long-term prospects
                                for the client's business development. This
                                helps us get the idea of what the top product on
                                the market looks, feels, and works like in order
                                to implement the best practices.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="row">
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class="img-1st"
                                    src="../../../assets/img/research.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <img
                                    src="../../../assets/img/border-1.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <div class="img-2nd center">
                                    <span>02</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="center">
                                <img
                                    class=""
                                    src="../../../assets/img/arrow-1.png"
                                    alt="Avatar"
                                />
                            </div>
                        </div>

                        <div class="content-box">
                            <h4 class="center">
                                <a href="" style="color: #92e3a9"
                                    >Interface design
                                </a>
                            </h4>
                            <p>
                                Solutions created for a wide target audience
                                require a thorough approach to UI development.
                                That’s why our UI designers often resort to the
                                most accessible design templates that allow
                                non-tech-savvy users to get a good hang of the
                                end software. Along with this, we never neglect
                                the personal client’s wishes, finding
                                compromises between convenience and general
                                vision of design.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="row">
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class="img-1st"
                                    src="../../../assets/img/blueprint.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <img
                                    src="../../../assets/img/border-1.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <div class="img-2nd center">
                                    <span>03</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="center">
                                <img
                                    src="../../../assets/img/arrow-1.png"
                                    alt="Avatar"
                                />
                            </div>
                        </div>

                        <div class="content-box wow slideInUp animated">
                            <h4 class="center">
                                <a href="" style="color: #92e3a9"
                                    >End-to-end testing
                                </a>
                            </h4>
                            <p>
                                Our QA team of specialists will create a list of
                                test cases that will cover the software code of
                                the developed solution far and wide. This helps
                                us minimize bugs and prevent many potential
                                flaws, which means that you won’t have to deal
                                with a barrage of user complaints.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- first ROW End -->

            <!-- third ROW strat -->
            <div class="row">
                <div class="col-md-4">
                    <div class="row">
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class="img-1st"
                                    src="../../../assets/img/deploy.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <img
                                    src="../../../assets/img/border-1.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <div class="img-2nd center">
                                    <span>04</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="center">
                                <img
                                    class=""
                                    src="../../../assets/img/arrow-1.png"
                                    alt="Avatar"
                                />
                            </div>
                        </div>

                        <div class="content-box">
                            <h4 class="center">
                                <a href="" style="color: #92e3a9"
                                    >Performance trials in the field
                                </a>
                            </h4>
                            <p>
                                As part of our retail services software
                                development, we always check the created
                                software in the real operating environment on
                                all types of compatible devices. This eliminates
                                any risks associated with software
                                incompatibility, which is critical for such a
                                responsible type of business as real estate.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="row">
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class="img-1st"
                                    src="../../../assets/img/deploy.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <img
                                    src="../../../assets/img/border-1.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <div class="img-2nd center">
                                    <span>05</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="center">
                                <img
                                    class=""
                                    src="../../../assets/img/arrow-1.png"
                                    alt="Avatar"
                                />
                            </div>
                        </div>

                        <div class="content-box">
                            <h4 class="center">
                                <a href="" style="color: #92e3a9"
                                    >Tech support
                                </a>
                            </h4>
                            <p>
                                We strive for long-term relationships with our
                                clients, offering post-releases tech support and
                                advice. With us, you can always receive prompt
                                technical maintenance for a launched solution or
                                return it for the implementation of new
                                features, integrations, and scaling.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- third ROW End -->
        </div>
    </section>
    <!-- End nine different sections Section -->
</template>

<script>
import IndustriesLink from "../components/InductriesLink.vue";
export default {
    components: {
        IndustriesLink,
    },
    mounted() {
        document.title = "Real Estate | Excel IT AI";
        window.scrollTo({ top: 0, behavior: "smooth" });
    },
};
</script>

<style scoped>
.trasnport {
    background-image: url(../../../assets/images/industries/retail_software.jpg);
    width: 100%;
    background-position: center;
    background-repeat: no-repeat;
    background-size: fill;
    height: 100%;
    position: relative;
}

.trasnport::before {
    position: absolute;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 100%;
    content: "";
    background: rgba(21, 37, 53, 0.8);
}
.trasnport .container {
    position: relative;
    z-index: 100;
}
li:hover {
    color: #fff;
}

.technology {
    /* background: linear-gradient(
        to bottom,
        rgba(52, 78, 99, 0.9),
        rgba(52, 78, 99)
    ); */
    background: #fff;
}
.ul_tag_style li a,
.breadcumpul li a {
    text-decoration: none !important;
    color: #215670 !important;
}
.ul_tag_style li a:hover,
.breadcumpul li a:hover {
    color: black !important;
    text-decoration: none !important;
}
</style>
