<template>
    <h1>Login page</h1>
</template>

<script>
export default {
    mounted() {
        document.title = "LOGIN | Excel IT AI";
        window.scrollTo({ top: 0, behavior: "smooth" });
    },
};
</script>
