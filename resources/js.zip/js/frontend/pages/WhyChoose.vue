<template>
    <div class="container mt-5 py-5">
        <div class="row">
            <div class="col-12 col-md-6">
                <div class="con_1">
                    <div class="icon">
                        <i class="fal fa-globe-americas"></i>
                    </div>
                    <div>
                        <p
                            style="
                                margin: 2rem 0;
                                text-align: justify;
                                color: #215670;
                            "
                        >
                            At Excel IT AI, we develop innovative and creative
                            products and services that provide total
                            communication and information solutions. Among a
                            plethora of services, web design and development,
                            mobile application design and development tailor
                            made applications, ERPs, CRMs, e-commerce solutions,
                            business-to-business applications,
                            business-to-client applications, managed hosting and
                            internet portal management are few that we offer.
                            Satisfied clients around the globe bear testimony to
                            the quality of our work. As a leader in technology
                            exploring, Excel IT AI is committed to exporting
                            quality software worldwide. The general purpose of
                            Excel IT AI is to develop and promote advanced
                            information technologies for multi-user operation.
                            Excel IT AI business philosophy is to assure the
                            highest quality product, total client satisfaction,
                            timely delivery of solutions and the best quality
                            price ratio found in the industry. Our emphasis is
                            on offering a high degree of product user
                            friendliness through a positive, creative and
                            focused company staff. With our vast array of
                            software development, product development, are
                            experienced, we believe the creation of a robust,
                            user friendly and functionally rich software
                            solution is a risk-free proposition for Excel IT AI
                            and Client. We are confident that we will be able to
                            create an exceptional system that will meet and
                            exceed Client’s expectations and vision for the
                            proposed web application.
                        </p>
                    </div>
                </div>
            </div>

            <div class="col-12 col-md-6">
                <div class="image" style="margin-top: 25px">
                    <a
                        href="https://www.youtube.com/watch?v=zSwJXXFcVkw"
                        target="_blank"
                    >
                        <img
                            src="../../../assets/images/why_choose_us.png"
                            alt=""
                        />
                    </a>
                </div>
            </div>
        </div>
        <!-- start of title row  -->
        <div class="row mt-5">
            <div
                class="col-md-12 my-5"
                style="
                    display: flex;
                    justify-content: center;
                    align-items: center;
                "
            >
                <h2 class="global-title" style="text-align: center">
                    <span class="rounded">Why Choose Excel IT AI</span>
                </h2>
            </div>
        </div>
        <!-- end of title row  -->
        <!-- start of title content row  -->
        <div class="row">
            <div class="col-md-12">
                <h3
                    class="text-capitalize"
                    style="color: chocolate; font-family: sens-serif"
                >
                    Commitment to Transparency
                </h3>
                <p style="margin: 2rem 0; text-align: justify; color: #215670">
                    We believe that strong business relationships are built on
                    trust and reliability. We work in tandem with your team to
                    conceptualize and build the perfect platform, and we are
                    committed to offering fair, transparent pricing at every
                    stage of development. We give you all the information you
                    need to make the right business decisions.
                </p>
            </div>
            <div class="col-md-6">
                <h3
                    class="text-capitalize"
                    style="color: chocolate; font-family: sens-serif"
                >
                    Comprehensive Experience
                </h3>
                <p style="margin: 2rem 0; text-align: justify; color: #215670">
                    Our team has diverse technology stack experience and deep
                    expertise in cloud-based SaaS solutions. Whatever your
                    business’s unique needs, we’re here to create the solutions.
                </p>
            </div>
            <div class="col-md-6">
                <h3
                    class="text-capitalize"
                    style="color: chocolate; font-family: sens-serif"
                >
                    Lean Business Model
                </h3>
                <p style="margin: 2rem 0; text-align: justify; color: #215670">
                    Syberry uses a lean, global business model to create value
                    for our customers; we're headquartered in Austin, TX with an
                    operations center in Europe. This model translates to better
                    savings and higher-quality service than our competitors can
                    offer.
                </p>
            </div>
            <div class="col-md-6">
                <h3
                    class="text-capitalize"
                    style="color: chocolate; font-family: sens-serif"
                >
                    Customer-Centric Culture
                </h3>
                <p style="margin: 2rem 0; text-align: justify; color: #215670">
                    Syberry carefully selects each employee to align with our
                    customer-centric culture. We're serious about providing the
                    best quality software and service (at the best price) to add
                    value for our customers.
                </p>
            </div>
            <div class="col-md-6">
                <h3
                    class="text-capitalize"
                    style="color: chocolate; font-family: sens-serif"
                >
                    Capacity to Scale
                </h3>
                <p style="margin: 2rem 0; text-align: justify; color: #215670">
                    Syberry's team of more than 250 expert engineers can scale
                    any project. That means your software can grow with your
                    business.
                </p>
            </div>
        </div>
        <!-- end of title content row  -->
    </div>
</template>

<script>
export default {
    mounted() {
        document.title = "WHY CHOOSE US | Excel IT AI";
        window.scrollTo({ top: 0, behavior: "smooth" });
    },
};
</script>

<style scoped>
.image img {
    width: 100%;
    height: 100%;
}

.icon i {
    background-size: cover;

    text-align: center;

    size: 9px;
}
</style>
