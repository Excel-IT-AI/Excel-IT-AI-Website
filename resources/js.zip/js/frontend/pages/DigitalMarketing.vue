<template>
    <!-- web about part start -->
    <section class="mt-5 pt-5">
        <div class="container">
            <div class="row" style="text-align: center; padding-bottom: 50px">
                <h2 class="global-title">
                    <span class="rounded">Digital Marketing</span>
                </h2>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="web_about">
                        <p
                            style="
                                color: #152535;
                                text-align: justify;
                                letter-spacing: 0.1ch;
                            "
                        >
                            Our element advanced specialists execute powerful
                            web advertising arrangements in view of your
                            business targets. With 100% modified strategies and
                            centered site advancement methodology, we expand
                            client engagement. Our group of digital marketing
                            experts gives customer accomplishment on each
                            venture doled out from technique and configuration
                            to web showcasing and versatile improvement. We will
                            offer you some assistance with exceeding your
                            desires.
                        </p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div
                        id="carouselExampleControls"
                        class="carousel slide"
                        data-bs-ride="carousel"
                    >
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <img
                                    src="../../../assets/images/services/digital/d1.jpg"
                                    class="d-block w-100"
                                    alt="..."
                                />
                            </div>
                            <div class="carousel-item">
                                <img
                                    src="../../../assets/images/services/digital/d2.jpg"
                                    class="d-block w-100"
                                    alt="..."
                                />
                            </div>
                            <div class="carousel-item">
                                <img
                                    src="../../../assets/images/services/digital/d3.jpg"
                                    class="d-block w-100"
                                    alt="..."
                                />
                            </div>
                        </div>
                        <button
                            class="carousel-control-prev"
                            type="button"
                            data-bs-target="#carouselExampleControls"
                            data-bs-slide="prev"
                        >
                            <span
                                class="carousel-control-prev-icon"
                                aria-hidden="true"
                            ></span>
                            <span class="visually-hidden">Previous</span>
                        </button>
                        <button
                            class="carousel-control-next"
                            type="button"
                            data-bs-target="#carouselExampleControls"
                            data-bs-slide="next"
                        >
                            <span
                                class="carousel-control-next-icon"
                                aria-hidden="true"
                            ></span>
                            <span class="visually-hidden">Next</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- web about part start -->
    <!-- web offer part start -->
    <section class="web_offer">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 mt-4 mb-4">
                    <h2
                        class="text-center global-title"
                        style="color: chocolate"
                    >
                        <span class="rounded"> What We Offer</span>
                    </h2>
                </div>
            </div>
            <div class="row" style="padding-bottom: 50px">
                <div class="col-md-4" data-aos="flip-left">
                    <div class="offer">
                        <span class="elementor-icon-list-icon">
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fas fa-bullhorn"
                            ></i>
                            Social Media marketing (smm)</span
                        >
                        <br />
                        <span class="elementor-icon-list-icon">
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fas fa-envelope"
                            ></i>
                            Email Marketing</span
                        >
                        <br />
                        <span
                            class="elementor-icon-list-icon"
                            style="margin-right: 10px"
                        >
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fas fa-search-plus"
                            ></i>
                            Search Engine Optimization (seo)
                        </span>
                        <br />
                        <span class="elementor-icon-list-icon">
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fas fa-bullhorn"
                            ></i>
                            Affiliate Marketing</span
                        >
                    </div>
                </div>
                <div class="col-md-4" data-aos="flip-up">
                    <div class="offer">
                        <span class="elementor-icon-list-icon">
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fas fa-video"
                            ></i>

                            Video Marketing</span
                        >
                        <br />
                        <span class="elementor-icon-list-icon">
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fas fa-file-audio"
                            ></i>
                            Audio Marketing</span
                        >
                        <br />
                        <span class="elementor-icon-list-icon">
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fas fa-cog"
                            ></i>
                            Content research</span
                        >
                    </div>
                </div>
                <div class="col-md-4" data-aos="flip-right">
                    <div class="offer">
                        <span class="elementor-icon-list-icon">
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fas fa-users"
                            ></i>
                            Lead Generation
                        </span>
                        <br />
                        <span class="elementor-icon-list-icon">
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fas fa-globe"
                            ></i>
                            Web Research</span
                        >
                        <br />
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- web offer part end -->

    <!-- Technologies  uses part start -->
    <section>
        <div class="container">
            <div class="row">
                <div class="col-sm-12 mt-4 mb-4">
                    <h4
                        class="global-title"
                        style="text-align: center; text-transform: uppercase"
                    >
                        <span class="rounded">Technologies that we use</span>
                    </h4>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <!-- owl-carousel section  -->
                    <div class="owl-carousel owl-theme owl-loaded pb-3">
                        <div class="owl-stage-outer">
                            <div class="owl-stage">
                                <div class="owl-item">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/digital_sliders/fb.png"
                                            /></a>
                                        </div>
                                        <div class="col-md-4 d-none d-md-block">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/digital_sliders/linkedin.jpg"
                                            /></a>
                                        </div>
                                        <div class="col-md-4 d-none d-md-block">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/digital_sliders/seo.png"
                                            /></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="owl-item">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/digital_sliders/twitter.png"
                                            /></a>
                                        </div>
                                        <div class="col-md-4 d-none d-md-block">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/digital_sliders/linkedin.jpg"
                                            /></a>
                                        </div>
                                        <div class="col-md-4 d-none d-md-block">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/digital_sliders/fb.png"
                                            /></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end of owl-carousel section  -->
                </div>
            </div>
        </div>
    </section>
    <!-- Technologies  uses part end -->

    <div class="container">
        <div class="row">
            <div
                class="
                    col-md-12
                    d-flex
                    justify-content-center
                    align-items-center
                "
            >
                <p class="get_quote_button">
                    <router-link :to="{ name: 'Contact' }" class=""
                        >get a free quote now</router-link
                    >
                </p>
            </div>
        </div>
    </div>
</template>

<script>
import SliderFont from "../../../assets/js/slider_font";
import OwlCarousel from "../../../assets/js/owl.carousel.min.js";
export default {
    mounted() {
        OwlCarousel();
        // require("../../../assets/js/owl.carousel.min.js");
        SliderFont();
        document.title = "DIGITAL MARKETING | Excel IT AI";
        window.scrollTo({ top: 0, behavior: "smooth" });
    },
};
</script>

<style scoped>
@import "../../../assets/css/bootstrap5.min.css";
@import "../css/home_slider_trusted_company.css";
ul {
    margin: 0;
    padding: 0;
    list-style: none;
}

a {
    text-decoration: none;
}

p {
    font-size: 18px;
    line-height: 1.2;
}

h1,
h2,
h3,
h4,
h5,
h6 {
    font-family: "Courier New", Courier, monospace;
    font-weight: 700;
    line-height: 1.2;
}

h1 {
    font-size: 3.375rem;
}

h2 {
    font-size: 2rem;
}

.thumbnail {
    width: 100%;
    height: 100%;
}
.thumbnail img {
    width: 150px !important;
    height: 150px !important;
    object-fit: fill;
}

.elementor-icon-list-icon {
    color: black !important;
}
.elementor-icon-list-icon span i {
    margin-right: 10px !important;
}
</style>
