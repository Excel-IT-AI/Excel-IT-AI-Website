<template>
    <!-- web about part start -->
    <section class="mt-5 pt-5">
        <div class="container">
            <div class="row" style="text-align: center; padding-bottom: 50px">
                <h2 class="global-title">
                    <span class="rounded">Mobile Application</span>
                </h2>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="web_about" data-aos="fade-right">
                        <p
                            style="
                                color: #152535;
                                text-align: justify;
                                letter-spacing: 0.1ch;
                                word-spacing: 0.1ch;
                            "
                        >
                            Our mobile application development solutions include
                            various domains and topics. This service is about
                            creating mobile applications for end-user
                            smartphones, tablets, and other devices. In general,
                            you can get full-cycle software development with all
                            the necessary stages: business analysis,
                            architecture planning, UI/UX design and prototyping,
                            development, testing and QA, release with deployment
                            or publication, and further tech support. If you
                            need unique mobile application development, we’re
                            ready to handle it. You can get solutions for iOS,
                            Android, and more exotic mobile operating systems
                            like Chrome OS, Tizen, or Ubuntu Touch. Apart from
                            native solutions (developed for the specific
                            platform), we provide hybrid and cross-platform
                            mobile applications that work seamlessly on
                            different devices. Don’t hesitate to contact us if
                            you need to consult or order custom mobile
                            development services. More precisely, the services
                            provided by our mobile app company include:
                            Smartphones appeared and changed our life
                            completely. Now, the tiniest phone is more powerful
                            than the computers of the past. No surprise that
                            mobile app development covers all our needs
                            nowadays, from communication to work and leisure.
                            That’s why businesses focus on mobile app
                            development heavily, creating various solutions for
                            individuals and other companies. If you want to get
                            a brand-new mobile application, improve or redesign
                            any existing tool, test demand with the MVP, or just
                            consult about mobile app development services,
                            you’re in the right place. We research, design,
                            build, deploy, test, and support native, hybrid, and
                            cross-platform mobile apps for Android and iOS. Our
                            mobile app development company is focusing on
                            effective solutions that meet the goals of our
                            clients. You can reach us to get the first free
                            consultation at any time.
                        </p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div
                        id="carouselExampleControls"
                        class="carousel slide"
                        data-bs-ride="carousel"
                    >
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <img
                                    src="../../../assets/images/services/mobile1.jpg"
                                    class="d-block w-100"
                                    alt="..."
                                />
                            </div>
                            <div class="carousel-item">
                                <img
                                    src="../../../assets/images/services/mobile2.jpg"
                                    class="d-block w-100"
                                    alt="..."
                                />
                            </div>
                            <div class="carousel-item">
                                <img
                                    src="../../../assets/images/services/mobile3.jpg"
                                    class="d-block w-100"
                                    alt="..."
                                />
                            </div>
                        </div>
                        <button
                            class="carousel-control-prev"
                            type="button"
                            data-bs-target="#carouselExampleControls"
                            data-bs-slide="prev"
                        >
                            <span
                                class="carousel-control-prev-icon"
                                aria-hidden="true"
                            ></span>
                            <span class="visually-hidden">Previous</span>
                        </button>
                        <button
                            class="carousel-control-next"
                            type="button"
                            data-bs-target="#carouselExampleControls"
                            data-bs-slide="next"
                        >
                            <span
                                class="carousel-control-next-icon"
                                aria-hidden="true"
                            ></span>
                            <span class="visually-hidden">Next</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- web about part start -->

    <!-- start of title row  -->
    <div class="container mt-5">
        <div
            class="col-md-12 my-5"
            style="display: flex; justify-content: center; align-items: center"
        >
            <h2 class="global-title">
                <span class="rounded">Benefits</span>
            </h2>
        </div>
    </div>
    <!-- end of title row  -->

    <!-- start of title content row  -->
    <div class="container row">
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                from our app development services
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                If you need professional mobile app development services, it’s
                better to carefully analyze all pros and cons. Compared to other
                cooperation options like freelance development or ready-made
                proprietary apps, our custom client-focused approach has a few
                advantages:
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Better engagement
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                Well-thought mobile applications improve the customer
                experience. Thus, you can attract more clients, interact with
                them simpler, and provide new services.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Custom monitoring
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                Using our in-house project control solution for mobile
                development – the Customer Portal – you have all data with
                metrics and updates under one roof.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Reduction of development expenses
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                Eventually, you cut development time and costs thanks to custom
                Agile approaches. We work for the result, not hours.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Fully tailored to your needs
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                Custom mobile app development services meet your requirements
                and provide exactly what you need for your business.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                New revenue channels
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                Combined, these benefits increase your profits. Customers
                appreciate responsive and personalized services provided via
                mobile channels.
            </p>
        </div>
    </div>
    <!-- end of title content row  -->

    <!-- web offer part start -->
    <section class="web_offer">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 mt-4 mb-4">
                    <h2 class="text-center global-title">
                        <span class="rounded"> What We Offer</span>
                    </h2>
                </div>
            </div>
            <div class="row" style="padding-bottom: 50px">
                <div class="col-md-4" data-aos="flip-left">
                    <div class="offer">
                        <span class="elementor-icon-list-icon">
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fab fa-xbox"
                            ></i>
                            Android development</span
                        >
                        <br />
                        <span class="elementor-icon-list-icon">
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fas fa-calendar"
                            ></i>
                            Apps for wearables and smart gadgets</span
                        >
                        <br />
                        <span
                            class="elementor-icon-list-icon"
                            style="margin-right: 10px"
                        >
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fas fa-drafting-compass"
                            ></i>
                            Cross-platform development
                        </span>
                        <br />
                        <span class="elementor-icon-list-icon">
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fas fa-dungeon"
                            ></i>
                            Extensions for web apps</span
                        >
                        <br />
                        <span class="elementor-icon-list-icon">
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fas fa-dungeon"
                            ></i>
                            Public app development</span
                        >
                    </div>
                </div>
                <div class="col-md-4" data-aos="flip-up">
                    <div class="offer">
                        <span class="elementor-icon-list-icon">
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fas fa-city"
                            ></i>
                            Integrations of modules</span
                        >
                        <br />
                        <span class="elementor-icon-list-icon">
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fas fa-cross"
                            ></i>
                            MVP and POC development services</span
                        >
                        <br />
                        <span class="elementor-icon-list-icon">
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fas fa-cog"
                            ></i>
                            iOS development</span
                        >
                        <br />
                        <span class="elementor-icon-list-icon">
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fas fa-cog"
                            ></i>
                            E-commerce app development</span
                        >
                        <br />
                        <span class="elementor-icon-list-icon">
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fas fa-cog"
                            ></i>
                            Game development</span
                        >
                    </div>
                </div>
                <div class="col-md-4" data-aos="flip-right">
                    <div class="offer">
                        <span class="elementor-icon-list-icon">
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fas fa-torah"
                            ></i>
                            Corporate app development
                        </span>
                        <br />
                        <span class="elementor-icon-list-icon">
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fas fa-ethernet"
                            ></i>
                            Publications in app stores</span
                        >
                        <br />
                        <span class="elementor-icon-list-icon">
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fas fa-compress-arrows-alt"
                            ></i>
                            Corporate app development</span
                        >
                        <br />
                        <span class="elementor-icon-list-icon">
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fas fa-compress-arrows-alt"
                            ></i>
                            Financial app development</span
                        >
                        <br />
                        <span class="elementor-icon-list-icon">
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fas fa-compress-arrows-alt"
                            ></i>
                            Maps and location app development</span
                        >
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- web offer part end -->

    <!-- section 2nd start  -->

    <section class="web_offer" style="font-family: sens-serif">
        <div class="container">
            <div class="row" style="padding-bottom: 50px">
                <div class="col-md-6">
                    <!-- header section  -->
                    <div class="row">
                        <div class="col-sm-12 mt-4 mb-4">
                            <h3
                                class="text-capitalize"
                                style="
                                    color: chocolate;
                                    font-family: sens-serif;
                                "
                            >
                                what impacts your project duration
                            </h3>
                            <p style="color: #215670">
                                The schedule of app development services depends
                                heavily on some critical factors
                            </p>
                        </div>
                    </div>
                    <!-- end of header section  -->
                    <!-- list body  -->

                    <div class="offer">
                        <span class="elementor-icon-list-icon">
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fab fa-xbox"
                            ></i>

                            Project requirements</span
                        >
                        <br />
                        <span class="elementor-icon-list-icon">
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fas fa-calendar"
                            ></i>
                            Expected deadlines</span
                        >
                        <br />
                        <span
                            class="elementor-icon-list-icon"
                            style="margin-right: 10px"
                        >
                            <i
                                style="color: rgb(209, 138, 30)"
                                aria-hidden="true"
                                class="fas fa-drafting-compass"
                            ></i>
                            Team composition
                        </span>
                        <br />
                        <span class="elementor-icon-list-icon">
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fas fa-tools"
                            ></i>
                            The available technologies and platforms</span
                        >
                        <br />
                        <span class="elementor-icon-list-icon">
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fab fa-uncharted"
                            ></i>
                            Assistance with publications in app stores</span
                        >
                    </div>
                    <!-- end of list body  -->
                </div>

                <!--  end dev  -->

                <!-- start dev -->

                <div class="col-md-6">
                    <!-- header section  -->
                    <div class="row">
                        <div class="col-sm-12 mt-4 mb-4">
                            <h3
                                class="text-capitalize"
                                style="
                                    color: chocolate;
                                    font-family: sens-serif;
                                "
                            >
                                what affects your project costs
                            </h3>
                            <p style="color: #215670">
                                with the total cost of your custom mobile app
                                development, the situation is similar to
                                schedules. the core factors are:
                            </p>
                        </div>
                    </div>
                    <!-- end of header section  -->

                    <div class="offer">
                        <span class="elementor-icon-list-icon">
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fas fa-torah"
                            ></i>
                            Project scope and complexity
                        </span>
                        <br />
                        <span class="elementor-icon-list-icon">
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fas fa-globe"
                            ></i>
                            The chosen technology</span
                        >
                        <br />
                        <span class="elementor-icon-list-icon">
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fas fa-desktop"
                            ></i>
                            Project completion urgency</span
                        >
                        <br />
                        <span class="elementor-icon-list-icon">
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fas fa-mobile"
                            ></i>
                            Engagement model: Fixed Price, Time and Material,
                            Dedicated Team</span
                        >
                        <br />
                        <span class="elementor-icon-list-icon">
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fas fa-globe"
                            ></i>
                            Post-launch extra requests like tech support</span
                        >
                        <br />
                    </div>
                </div>
                <!-- end dev -->
                <!-- start dev -->
            </div>
        </div>
    </section>

    <!-- section 2nd end -->

    <!-- our teach stack part start -->
    <section class="web_offer">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 mt-4 mb-4">
                    <h2
                        class="text-center global-title"
                        style="font-family: sans-serif"
                    >
                        <span class="rounded">Our Tech Stack</span>
                    </h2>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="container row">
                        <div class="col-md-12">
                            <h3
                                class="text-capitalize"
                                style="
                                    color: chocolate;
                                    font-family: sens-serif;
                                "
                            >
                                Frontend Development
                            </h3>
                            <p
                                style="
                                    margin: 2rem 0;
                                    text-align: justify;
                                    color: #215670;
                                "
                            >
                                Speeding up app's delivery together with money
                                savings is a perfect mix. Both, Flutter and
                                React Native, by using a massive collection of
                                libraries and other ready to use components
                                shorten the time to go live on the market.
                            </p>
                        </div>
                        <div class="row" style="padding-bottom: 50px">
                            <div class="col-md-6">
                                <div class="offer">
                                    <span
                                        class="elementor-icon-list-icon p-3"
                                        style="color: black"
                                    >
                                        <img
                                            src="/images/mobile_service/flutter_logo.png"
                                            width="50"
                                            class="my-3"
                                        />
                                        Flutter</span
                                    >
                                    <br />
                                    <span
                                        class="elementor-icon-list-icon p-3"
                                        style="color: black"
                                    >
                                        <img
                                            src="/images/mobile_service/kotlin.png"
                                            width="60"
                                            class="my-3"
                                        />
                                        Kotline</span
                                    >
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="offer">
                                    <span
                                        class="elementor-icon-list-icon p-3"
                                        style="margin-right: 10px; color: black"
                                    >
                                        <img
                                            src="/images/mobile_service/react_native.png"
                                            width="40"
                                            class="my-3"
                                        />
                                        React Native
                                    </span>
                                    <br />
                                    <span
                                        class="elementor-icon-list-icon p-3"
                                        style="margin-right: 10px; color: black"
                                    >
                                        <img
                                            src="/images/mobile_service/swift.png"
                                            width="40"
                                            class="my-3"
                                        />
                                        Swift
                                    </span>
                                    <br />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="container row">
                        <div class="col-md-12">
                            <h3
                                class="text-capitalize"
                                style="
                                    color: chocolate;
                                    font-family: sens-serif;
                                "
                            >
                                Backend Development
                            </h3>
                            <p
                                style="
                                    margin: 2rem 0;
                                    text-align: justify;
                                    color: #215670;
                                "
                            >
                                We deliver complex, secure and well-documented
                                backend solutions with resizable computing
                                capacity that scale naturally within the
                                industry’s best cloud platforms. Whether it’s a
                                web app, custom backend system or an API, we
                                create architectures that best suit your digital
                                products.
                            </p>
                        </div>
                        <div class="row" style="padding-bottom: 50px">
                            <div class="col-md-4">
                                <div class="offer">
                                    <span
                                        class="elementor-icon-list-icon p-3"
                                        style="color: black"
                                    >
                                        <img
                                            src="/images/mobile_service/laravel.png"
                                            width="50"
                                            class="my-3"
                                        />
                                        Laravel</span
                                    >
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="offer">
                                    <span
                                        class="elementor-icon-list-icon p-3"
                                        style="color: black"
                                    >
                                        <img
                                            src="/images/mobile_service/python.png"
                                            width="50"
                                            class="my-3"
                                        />
                                        Python</span
                                    >
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="offer">
                                    <span
                                        class="elementor-icon-list-icon p-3"
                                        style="color: black"
                                    >
                                        <img
                                            src="/images/mobile_service/nodejs.png"
                                            width="50"
                                            class="my-3"
                                        />
                                        Node Js</span
                                    >
                                    <br />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--  our teach stack  part end -->

    <!-- Technologies  uses part start -->
    <!-- <section>
        <div class="container">
            <div class="row">
                <div class="col-sm-12 mt-4 mb-4">
                    <h2
                        class="text-center global-title"
                        style="color: rgb(31, 184, 64)"
                    >
                        <span class="rounded"> Technologies we use</span>
                    </h2>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="owl-carousel owl-theme owl-loaded pb-3">
                        <div class="owl-stage-outer">
                            <div class="owl-stage">
                                <div class="owl-item">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="./././assets/images/technologies/android_logo.png"
                                            /></a>
                                        </div>
                                        <div class="col-md-4 d-none d-md-block">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="./../../assets/images/technologies/cplusplus_logo.png"
                                            /></a>
                                        </div>
                                        <div class="col-md-4 d-none d-md-block">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/technologies/flutter.png"
                                            /></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="owl-item">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/technologies/ionic.png"
                                            /></a>
                                        </div>
                                        <div class="col-md-4 d-none d-md-block">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/technologies/ios.png"
                                            /></a>
                                        </div>
                                        <div class="col-md-4 d-none d-md-block">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/technologies/java.png"
                                            /></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="owl-item">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/technologies/kotlin.png"
                                            /></a>
                                        </div>
                                        <div class="col-md-4 d-none d-md-block">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/technologies/react-native.png"
                                            /></a>
                                        </div>
                                        <div class="col-md-4 d-none d-md-block">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/technologies/objective_c.png"
                                            /></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="owl-item">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/technologies/typescript.png"
                                            /></a>
                                        </div>
                                        <div class="col-md-4 d-none d-md-block">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/technologies/xamarin_logo.png"
                                            /></a>
                                        </div>
                                        <div class="col-md-4 d-none d-md-block">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/technologies/xml.jpg"
                                            /></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="owl-item">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/technologies/javascript.png"
                                            /></a>
                                        </div>
                                        <div class="col-md-4 d-none d-md-block">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/technologies/objective_c.png"
                                            /></a>
                                        </div>
                                        <div class="col-md-4 d-none d-md-block">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/technologies/swift-logo.png"
                                            /></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section> -->
    <!-- Technologies  uses part end -->

    <!--custom software  part start -->
    <section class="web_offer" style="font-family: sens-serif">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 mt-4 mb-4">
                    <h2
                        class="text-center global-title"
                        style="font-family: sens-serif"
                    >
                        <span class="rounded">
                            Our Mobile App development process
                        </span>
                    </h2>
                </div>
                <div class="col-sm-12 mt-4 mb-4">
                    <p style="color: #215670; text-transform: capitalize">
                        the process of custom mobile app development relies on
                        the same standard-based principles as other dev options
                        in DICEUS. We commit to Agile approaches but also have
                        experience in Scrum, Kanban, Waterfall, etc. Thus, there
                        are a few basic stages Of any project, from a simple
                        UI/UX redesign to full-stack app development services:
                    </p>
                </div>
            </div>
        </div>
    </section>
    <!-- custom software part end -->

    <!-- ======= nine different sections Section ======= -->
    <section id="why-us" class="why-us section-bg px-5 py-5">
        <div class="container-fluid">
            <!-- first ROW strat -->
            <div class="row">
                <div class="col-md-4">
                    <div class="row">
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class="img-1st"
                                    src="../../../assets/img/bigdata.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <img
                                    src="../../../assets/img/border-1.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <div class="img-2nd center">
                                    <span>01</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class=""
                                    src="../../../assets/img/arrow-1.png"
                                    alt="Avatar"
                                />
                            </div>
                        </div>

                        <div class="content-box">
                            <h4 class="center">
                                <a href="" style="color: #92e3a9"
                                    >Business Analysis
                                </a>
                            </h4>
                            <p>
                                The first phase provides for a complete
                                understanding Of your requirements and the
                                desired results. Based on this analysis, we
                                define the scope, plan features, architecture
                                patterns, and initial documentation, such as
                                SRS.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="row">
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class="img-1st"
                                    src="../../../assets/img/research.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <img
                                    src="../../../assets/img/border-1.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <div class="img-2nd center">
                                    <span>02</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="center">
                                <img
                                    class=""
                                    src="../../../assets/img/arrow-1.png"
                                    alt="Avatar"
                                />
                            </div>
                        </div>

                        <div class="content-box">
                            <h4 class="center">
                                <a href="" style="color: #92e3a9"
                                    >Product Design
                                </a>
                            </h4>
                            <p>
                                The next big step includes end-to-end UI/UX
                                design. You get basic wireframes, mockups, low-
                                and high- fidelity prototypes. They show the
                                app's structure, graphics, interactive elements,
                                other visuals, etc.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="row">
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class="img-1st"
                                    src="../../../assets/img/blueprint.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <img
                                    src="../../../assets/img/border-1.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <div class="img-2nd center">
                                    <span>03</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="center">
                                <img
                                    src="../../../assets/img/arrow-1.png"
                                    alt="Avatar"
                                />
                            </div>
                        </div>

                        <div class="content-box wow slideInUp animated">
                            <h4 class="center">
                                <a href="" style="color: #92e3a9"
                                    >Development
                                </a>
                            </h4>
                            <p>
                                The dev phase may start with the MVP or Minimum
                                Viable Product that helps test user demand
                                without spending much money. Further, we develop
                                the Final product For the target platform or
                                platforms using the relevant tools.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- first ROW End -->

            <!-- third ROW strat -->
            <div class="row">
                <div class="col-md-4">
                    <div class="row">
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class="img-1st"
                                    src="../../../assets/img/deploy.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <img
                                    src="../../../assets/img/border-1.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <div class="img-2nd center">
                                    <span>04</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="center">
                                <img
                                    class=""
                                    src="../../../assets/img/arrow-1.png"
                                    alt="Avatar"
                                />
                            </div>
                        </div>

                        <div class="content-box">
                            <h4 class="center">
                                <a href="" style="color: #92e3a9">QA </a>
                            </h4>
                            <p>
                                During all stages, our mobile application
                                development company handles iterative testing
                                sessions that show how the application meets
                                your requirements. We perform various types of
                                testing, including system, integration,
                                usability, performance, etc.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="row">
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class="img-1st"
                                    src="../../../assets/img/deploy.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <img
                                    src="../../../assets/img/border-1.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <div class="img-2nd center">
                                    <span>05</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="center">
                                <img
                                    class=""
                                    src="../../../assets/img/arrow-1.png"
                                    alt="Avatar"
                                />
                            </div>
                        </div>

                        <div class="content-box">
                            <h4 class="center">
                                <a href="" style="color: #92e3a9"
                                    >Deployement
                                </a>
                            </h4>
                            <p>
                                Finally, after everything's developed and
                                tested, it’s time to release the mobile app.
                                Usvally, it’s the client-side process, but we
                                can assist with it. Also, we can publish your
                                application to make sure that it’s accessible
                                for users.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="row">
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class="img-1st"
                                    src="../../../assets/img/deploy.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <img
                                    src="../../../assets/img/border-1.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <div class="img-2nd center">
                                    <span>06</span>
                                </div>
                            </div>
                        </div>

                        <div class="content-box">
                            <h4 class="center">
                                <a href="" style="color: #92e3a9"
                                    >Further Support
                                </a>
                            </h4>
                            <p>
                                Publication and deployment often end the first
                                process. But you can get regular tech support
                                and maintenance, ask for extra changes or
                                upgrades, order major or basic redesign services
                                further.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- third ROW End -->
        </div>
    </section>
    <!-- End nine different sections Section -->

    <div class="container">
        <div class="row">
            <div
                class="
                    col-md-12
                    d-flex
                    justify-content-center
                    align-items-center
                "
            >
                <p class="get_quote_button">
                    <router-link :to="{ name: 'Contact' }" class=""
                        >get a free quote now</router-link
                    >
                </p>
            </div>
        </div>
    </div>
</template>

<script>
import SliderFont from "../../../assets/js/slider_font";
import OwlCarousel from "../../../assets/js/owl.carousel.min.js";
export default {
    mounted() {
        OwlCarousel();
        SliderFont();
        document.title = "Mobile Application | Excel IT AI";
        window.scrollTo({ top: 0, behavior: "smooth" });
    },
};
</script>

<style scoped>
@import "../../../assets/css/bootstrap5.min.css";
@import "../css/home_slider_trusted_company.css";
ul {
    margin: 0;
    padding: 0;
    list-style: none;
}

a {
    text-decoration: none;
}

p {
    font-size: 18px;
    line-height: 1.2;
}

h1,
h2,
h3,
h4,
h5,
h6 {
    font-family: "Courier New", Courier, monospace;
    font-weight: 700;
    line-height: 1.2;
}

h1 {
    font-size: 3.375rem;
}

h2 {
    font-size: 2rem;
}
.thumbnail {
    width: 100%;
    height: 100%;
}
.thumbnail img {
    width: 150px !important;
    height: 150px !important;
    object-fit: fill;
}

.elementor-icon-list-icon {
    color: black !important;
}

/* custosoftware process  */

.img-1st {
    border-radius: 50%;
    height: 75px;
    width: 75px;
    border-style: dotted;
    border-width: 2px;
    border-color: #92e3a9;
    text-align: center;
    padding: 1px;
    transition: 0.3s;
}
.img-2nd {
    border-radius: 50%;
    height: 50px;
    width: 50px;
    /* border-style: solid; */
    /* border-width: 1px; */
    /* border-color: #fb6064; */
    text-align: center;
    padding-top: 4px;
}
.img-2nd span {
    position: relative;
    display: inline-block;
    width: 40px;
    height: 40px;
    line-height: 40px;
    font-size: 15px;
    font-family: "Muli", Sans-serif;
    font-weight: 700;
    color: #fff;
    border-radius: 50%;
    background-color: red;
    border-color: floralwhite;
    border: 2px;
}
.center {
    display: block;
    margin-left: auto;
    margin-right: auto;
    width: 50%;
    text-align: center;
    /* border: 1px solid; */
    /* border: 1px solid red; */
}

.img-1st:hover {
    background-color: #92e3a9;
    cursor: pointer;
}

.content-box {
    height: auto;
    width: 300px;
    position: relative;
    display: block;
    background: linear-gradient(to bottom, rgb(65, 95, 205), rgb(68, 144, 188));
    padding: 47px 30px 43px 30px;
    border-radius: 30px;
    margin-left: 10px;
    box-shadow: 0 10px 30px rgb(0 0 0 / 10%);
    margin-top: 50px;
    margin-bottom: 50px;
    border: 10px solid #92e3a9;
    /* border: 10px solid #215670; */
}
.content-box h4 a {
    font-size: 1.3rem !important;
}

.content-box p {
    color: #fff;
}
</style>
