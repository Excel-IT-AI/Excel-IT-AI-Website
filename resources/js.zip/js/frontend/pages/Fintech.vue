<template>
    <!-- industries top title section start -->
    <section class="fintech mt-5" style="padding: 50px 0px 50px 0px">
        <div class="container">
            <div class="row" style="text-align: center; padding-bottom: 50px">
                <h1 class="global-title">
                    <span class="rounded">Fintech</span>
                </h1>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <!-- <h3
                        style="
                            text-align: center;
                            font-weight: bold;
                            color: darkorange;
                            text-transform: capitalize;
                        "
                    >
                        Banking and financial software development expertise
                    </h3> -->
                    <br />
                    <p
                        style="
                            text-align: justify;
                            color: white;
                            word-spacing: 0.2ch;
                            text-transform: capitalize;
                            line-height: 25px;
                        "
                    >
                        We help a large number of our customers better
                        understand what challenges they can overcome by adopting
                        fintech. The fintech ecosystem is growing rapidly and
                        unites thousands of solutions for payments and
                        transfers, lending and financing, insurance, financial
                        management, markets and exchanges. Our team has strong
                        experience providing fintech software development
                        services by implementing both ready-made solutions and
                        custom apps. We not only deliver innovative software
                        products, but also ensure professional tech advisory and
                        support to manage changes to architecture that arise
                        after implementation.
                    </p>
                </div>
                <div class="col-md-2"></div>
                <div class="col-md-4">
                    <IndustriesLink></IndustriesLink>
                </div>
            </div>
        </div>
    </section>
    <!-- industries top title section end -->

    <!-- start of title row  -->
    <div class="container mt-5">
        <div
            class="col-md-12 my-5"
            style="
                display: flex;
                justify-content: center;
                align-items: center;
                flex-direction: column;
            "
        >
            <h3 style="font-size: 30px" class="global-title">
                <span class="rounded"> Key advantages</span>
            </h3>
            <p style="color: black; text-transform: uppercase">
                to choose Excel IT AI for fintech software development services
            </p>
        </div>
    </div>
    <!-- end of title row  -->

    <!-- start of title content row  -->
    <div class="container row">
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Fintech expertise
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                The financial industry has drastically changed as well as
                customer and market demands. If you want to stay competitive and
                deliver new up-to-date values to consumers, we are here to help
                you. Our team provides fintech development services to help you
                embrace new opportunities with artificial intelligence, big
                data, blockchain, cloud solutions, and many more.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Innovation partner
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                Our team has full-range fintech expertise, including lending
                management software, blockchain solutions, regtech, payments and
                transfers. That allows us to partner with various companies,
                from startups to billion-dollar organizations, to innovate and
                bring their ideas to life. We aim at becoming not only your
                software vendor but also a long-lasting, reliable partner for
                innovation.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Focus on results
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                We are a result-oriented fintech software development company
                offering teams where every member knows how valuable your time
                is. To ensure on-time software product delivery, we have
                established a quality-driven software development flow where we
                use business analysis, work breakdown structuring, critical path
                analysis, and traceability matrix. Combined with Agile best
                practices, all that guarantees successful outcomes.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                High quality
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                Well-defined quality assurance processes, regular code reviews
                and cross-code reviews, the latest bug tracking tools are one of
                the key things leading to project success. Before the
                cooperation, we define all the required metrics to measure the
                product quality in the service level agreement. Any bugs or
                other pressing issues are reported regularly to the client to
                inform them of further actions to be taken.
            </p>
        </div>
    </div>
    <!-- end of title content row  -->

    <!-- uses tecnology section start -->
    <!-- <section class="linear_gradient" style="padding: 50px 0px 50px 0px">
        <div class="container">
            <div class="row">
                <div class="col-sm-6 offset-sm-3 mt-4 mb-4">
                    <h4
                        class="global-title"
                        style="text-align: center; text-transform: uppercase"
                    >
                        <span class="rounded">Technologies that we use</span>
                    </h4>
                </div>
                <div class="col-sm-6 offset-sm-3 mt-4 mb-4">
                    <p
                        style="
                            color: #215670;
                            text-transform: capitalize;
                            font-family: sans-serif;
                        "
                    >
                        We denounce with righteos indignation and dislikes men
                        who are so beguiled demoralized cof pleasure of the
                        moment.
                    </p>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <ul style="color: black" class="ul_tag_style">
                        <li>
                            <a href="#">Hadoop and other Big Data Platorms</a>
                        </li>
                        <li><a href="#">Licensed OCR Tool</a></li>
                        <li><a href="#">Luigi Workflow Manager</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <ul style="color: black" class="ul_tag_style">
                        <li>
                            <a href="#">Distributed setup on Cloud for speed</a>
                        </li>
                        <li><a href="#">Django Framework</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <img
                        src="../../../assets/images/m2.jpeg"
                        class="img-fluid"
                        alt=""
                        style="height: 100%; border: 10px solid #92e3a9"
                    />
                </div>
            </div>
        </div>
    </section> -->
    <!-- uses tecnology section end -->

    <!--custom software  part start -->
    <section class="web_offer" style="font-family: sens-serif">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 mt-4 mb-4">
                    <h2
                        class="text-center global-title"
                        style="font-family: sens-serif"
                    >
                        <span class="rounded">
                            Our fintech development process
                        </span>
                    </h2>
                </div>
                <div class="col-sm-12 mt-4 mb-4">
                    <p
                        style="
                            color: #215670;
                            text-transform: capitalize;
                            font-family: sans-serif;
                        "
                    >
                        We have a well-defined development process for every
                        type of software product. Each project starts with the
                        initial phase, and goes on with requirements gathering
                        and business analysis. Next, come design and development
                        stages, testing, and deployment. On the closure phase,
                        we hand over all the project documentation and source
                        code to the client and offer further technical support
                        and maintenance.
                    </p>
                </div>
            </div>
        </div>
    </section>
    <!-- custom software part end -->

    <!-- start of title content row  -->
    <!-- <div class="container row">
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Business analysis
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                Any fintech project starts with a discovery phase during which
                we collect all functional and non-functional requirements. Once
                we have all the requirements, we develop and document software
                specifications and agree those with you. The in-depth business
                analysis allows for avoiding project failure, minimizing risks
                and errors, and delivering the product as expected.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Development
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                Our software development life cycle is built concerning best
                practices and approaches. Every project is run by a
                PMI-certified project manager, while the client is guided
                throughout the process by a key account manager. You can easily
                control the process, monitor the working hours of developers,
                see accomplished tasks via our unique customer portal.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Testing
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                The testing strategy is developed at the beginning of the
                project and is adhered to across the development. We define the
                required types of testing to be executed and perform it within
                the software development lifecycle. For fintech projects,
                testing is very critical as fintech software should ensure high
                security of data and functionalities.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Deployment
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                Your environment will be checked to identify if it is prepared
                for successful deployment. If we discover any issues, we will
                give notice to you and provide recommendations on how to resolve
                those. Before the deployment date, you will have to fix
                everything and be ready to collaborate with our specialists.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Support and maintenance
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                Troubleshooting, technical support, and maintenance are key
                services we offer after the software has been deployed. Use
                these services when you want to add new features, upgrade your
                software, or just need continuous technical support.
            </p>
        </div>
    </div> -->
    <!-- end of title content row  -->

    <!-- ======= nine different sections Section ======= -->
    <section id="why-us" class="why-us section-bg px-5 py-5">
        <div class="container-fluid">
            <!-- first ROW strat -->
            <div class="row">
                <div class="col-lg-4">
                    <div class="row">
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class="img-1st"
                                    src="../../../assets/img/bigdata.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <img
                                    src="../../../assets/img/border-1.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <div class="img-2nd center">
                                    <span>01</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class=""
                                    src="../../../assets/img/arrow-1.png"
                                    alt="Avatar"
                                />
                            </div>
                        </div>

                        <div class="content-box">
                            <h4 class="center">
                                <a href="" style="color: #92e3a9"
                                    >Business analysis</a
                                >
                            </h4>
                            <p>
                                Any fintech project starts with a discovery
                                phase during which we collect all functional and
                                non-functional requirements. Once we have all
                                the requirements, we develop and document
                                software specifications and agree those with
                                you. The in-depth business analysis allows for
                                avoiding project failure, minimizing risks and
                                errors, and delivering the product as expected.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="row">
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class="img-1st"
                                    src="../../../assets/img/research.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <img
                                    src="../../../assets/img/border-1.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <div class="img-2nd center">
                                    <span>02</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="center">
                                <img
                                    class=""
                                    src="../../../assets/img/arrow-1.png"
                                    alt="Avatar"
                                />
                            </div>
                        </div>

                        <div class="content-box">
                            <h4 class="center">
                                <a href="" style="color: #92e3a9"
                                    >Development
                                </a>
                            </h4>
                            <p>
                                Our software development life cycle is built
                                concerning best practices and approaches. Every
                                project is run by a PMI-certified project
                                manager, while the client is guided throughout
                                the process by a key account manager. You can
                                easily control the process, monitor the working
                                hours of developers, see accomplished tasks via
                                our unique customer portal.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="row">
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class="img-1st"
                                    src="../../../assets/img/blueprint.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <img
                                    src="../../../assets/img/border-1.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <div class="img-2nd center">
                                    <span>03</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="center">
                                <img
                                    src="../../../assets/img/arrow-1.png"
                                    alt="Avatar"
                                />
                            </div>
                        </div>

                        <div class="content-box wow slideInUp animated">
                            <h4 class="center">
                                <a href="" style="color: #92e3a9"> Testing </a>
                            </h4>
                            <p>
                                The testing strategy is developed at the
                                beginning of the project and is adhered to
                                across the development. We define the required
                                types of testing to be executed and perform it
                                within the software development lifecycle. For
                                fintech projects, testing is very critical as
                                fintech software should ensure high security of
                                data and functionalities.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- first ROW End -->

            <!-- third ROW strat -->
            <div class="row">
                <div class="col-lg-4">
                    <div class="row">
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class="img-1st"
                                    src="../../../assets/img/deploy.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <img
                                    src="../../../assets/img/border-1.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <div class="img-2nd center">
                                    <span>04</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="center">
                                <img
                                    class=""
                                    src="../../../assets/img/arrow-1.png"
                                    alt="Avatar"
                                />
                            </div>
                        </div>

                        <div class="content-box">
                            <h4 class="center">
                                <a href="" style="color: #92e3a9"
                                    >Deployment
                                </a>
                            </h4>
                            <p>
                                Your environment will be checked to identify if
                                it is prepared for successful deployment. If we
                                discover any issues, we will give notice to you
                                and provide recommendations on how to resolve
                                those. Before the deployment date, you will have
                                to fix everything and be ready to collaborate
                                with our specialists.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="row">
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class="img-1st"
                                    src="../../../assets/img/deploy.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <img
                                    src="../../../assets/img/border-1.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <div class="img-2nd center">
                                    <span>05</span>
                                </div>
                            </div>
                        </div>
                        <!-- <div class="col-md-6">
                            <div class="center">
                                <img
                                    class=""
                                    src="../../../assets/img/arrow-1.png"
                                    alt="Avatar"
                                />
                            </div>
                        </div> -->

                        <div class="content-box">
                            <h4 class="center">
                                <a href="" style="color: #92e3a9"
                                    >Support and maintenance
                                </a>
                            </h4>
                            <p>
                                Troubleshooting, technical support, and
                                maintenance are key services we offer after the
                                software has been deployed. Use these services
                                when you want to add new features, upgrade your
                                software, or just need continuous technical
                                support.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- third ROW End -->
        </div>
    </section>
    <!-- End nine different sections Section -->
</template>

<script>
import "../../../assets/css/bootstrap5.min.css";
import IndustriesLink from "../components/InductriesLink.vue";
export default {
    components: {
        IndustriesLink,
    },
    mounted() {
        document.title = "FINTECH | Excel IT AI";
        window.scrollTo({ top: 0, behavior: "smooth" });
    },
};
</script>

<style scoped>
.fintech {
    background-image: url(../../../assets/images/industries/web_development_bg.jpg);
    width: 100%;
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
    position: relative;
}
.fintech::before {
    position: absolute;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 100%;
    content: "";
    background: rgba(21, 37, 53, 0.8);
}
li,
h4 {
    color: rgba(25, 204, 160);
}
p,
li:hover,
a {
    color: #fff;
}
.linear_gradient {
    /* background: linear-gradient(
        to bottom,
        rgba(52, 78, 99, 0.9),
        rgba(52, 78, 99)
    ); */

    background: #fff;
}

.ul_tag_style li a,
.breadcumpul li a {
    text-decoration: none !important;
    color: #215670 !important;
}
.ul_tag_style li a:hover,
.breadcumpul li a:hover {
    color: black !important;
    text-decoration: none !important;
}

.elementor-icon-list-icon {
    color: black !important;
}

/* custosoftware process  */

.img-1st {
    border-radius: 50%;
    height: 75px;
    width: 75px;
    border-style: dotted;
    border-width: 2px;
    border-color: #92e3a9;
    text-align: center;
    padding: 1px;
    transition: 0.3s;
}
.img-2nd {
    border-radius: 50%;
    height: 50px;
    width: 50px;
    /* border-style: solid; */
    /* border-width: 1px; */
    /* border-color: #fb6064; */
    text-align: center;
    padding-top: 4px;
}
.img-2nd span {
    position: relative;
    display: inline-block;
    width: 40px;
    height: 40px;
    line-height: 40px;
    font-size: 15px;
    font-family: "Muli", Sans-serif;
    font-weight: 700;
    color: #fff;
    border-radius: 50%;
    background-color: red;
    border-color: floralwhite;
    border: 2px;
}
.center {
    display: block;
    margin-left: auto;
    margin-right: auto;
    width: 50%;
    text-align: center;
    /* border: 1px solid; */
    /* border: 1px solid red; */
}

.img-1st:hover {
    background-color: #92e3a9;
    cursor: pointer;
}

.content-box {
    height: auto;
    width: 300px;
    position: relative;
    display: block;
    background: linear-gradient(to bottom, rgb(65, 95, 205), rgb(68, 144, 188));
    padding: 47px 30px 43px 30px;
    border-radius: 30px;
    margin-left: 10px;
    box-shadow: 0 10px 30px rgb(0 0 0 / 10%);
    margin-top: 50px;
    margin-bottom: 50px;
    border: 10px solid #92e3a9;
    /* border: 10px solid #215670; */
}
.content-box h4 a {
    font-size: 1.3rem !important;
}

.content-box p {
    color: #fff;
}
</style>
