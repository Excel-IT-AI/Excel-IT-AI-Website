<template>
    <!-- industries top title section start -->
    <section class="trasnport mt-5" style="padding: 50px 0px 50px 0px">
        <div class="container">
            <div class="row" style="text-align: center; padding-bottom: 50px">
                <h2 class="global-title">
                    <span class="rounded">Real estate</span>
                </h2>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <br />
                    <p
                        style="
                            text-align: justify;
                            color: white;
                            word-spacing: 0.2ch;
                            text-transform: capitalize;
                            line-height: 25px;
                        "
                    >
                        Real estate management is a complex, highly customized
                        process. As any manager knows, every day is a new
                        adventure, with new issues to address and resident
                        concerns to juggle, But custom management software makes
                        it simple to keep everything running smoothly,
                        automating management details and making the community
                        feel like home, sweet home.
                    </p>
                </div>
                <div class="col-md-2"></div>
                <div class="col-md-4" data-aos="fade-left">
                    <IndustriesLink></IndustriesLink>
                </div>
            </div>
        </div>
    </section>
    <!-- industries top title section end -->

    <!-- start of title row  -->
    <div class="container mt-5">
        <div
            class="col-md-12 my-5"
            style="
                display: flex;
                justify-content: center;
                flex-direction: column;
                align-items: center;
            "
        >
            <h2 class="global-title">
                <span class="rounded"> Why Choose Custom Software?</span>
            </h2>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                While there are several off-the-shelf real estate management
                software options available on the market, their out-of-the-box
                features and clunky integration capabilities will make for a
                less-than-ideal experience. No real estimate management is
                alike, and no off-the-shelf solution can provide a 100 percent
                match for your organization’s needs.Custom software, on the
                other hand, is built with your specific business and its
                particular nuances and needs in mind. What’s more, you own the
                system, and you can make adjustments as needed, scaling it up to
                support expanding teams and seamlessly integrating it with other
                third-party solutions. In short, with custom software, you’re
                always in control.
            </p>
        </div>
    </div>
    <!-- end of title row  -->

    <!-- start of title content row  -->
    <div class="container row">
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Excel IT AI Custom Real Estate Management Software Lets You
                Control Your Territory
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                From finances to marketing to everyday maintenance, your custom
                real estate management system lets you customize the way you
                track and manage each of the many facets of your work.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Easy and robust UI
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                With intuitive, visually appealing front-end and back-end
                interfaces our custom software solutions make it easy for you
                and your tenants to take care of business.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Integration with existing systems
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                No need to worry about duplicated or incomplete data. Our
                solutions are designed to integrate seamlessly with your
                existing platforms, including CRMs, ERPs, inventories, and
                accounting systems.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Custom Marketing Tools
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                You know better than anyone how, when, and where to connect with
                your people, and our custom software applications are designed
                to supercharge your marketing efforts.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Customization of Existing Systems
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                Many smaller companies cannot afford to build a custom real
                estate management system from scratch, and that’s okay. If
                that’s the case, you can still benefit from system
                customization. In most cases, we can offer support, enhancement,
                and feature development on your existing systems, whether they
                were custom built or prefab. If your outdated legacy system is a
                fixer-upper, investing in a little renovation in order to
                improve both the tenant experience and internal workflows will
                go a long way in helping you stay ahead of the competition.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Application processing
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                Bringing in new tenants has never been easier, from vetting
                rental applicants to supporting buyers through the mortgage
                process.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Construction and maintenance management
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                From major renovations to minor repairs, our systems empower
                managers to process work orders, coordinate subcontractors, and
                ensure quality workmanship, keeping your properties looking (and
                living) as good as new.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Customized vendor and tenant management
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                Whether you’re processing rent and HOA dues or coordinating and
                paying vendors for their work, our accounting and CRM
                integration make bulk charges and payments simple to execute,
                record, and track.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Tenant satisfaction management
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                Discussion forums, tenant mass communication tools, local
                business reviews. We can build the user-friendly features your
                system needs to make your properties feel like communities and
                your units feel like homes.
            </p>
        </div>
    </div>
    <!-- end of title content row  -->

    <!--custom software  part start -->
    <section class="web_offer" style="font-family: sens-serif">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 mt-4 mb-4">
                    <h2
                        class="text-center global-title"
                        style="font-family: sens-serif"
                    >
                        <span class="rounded">
                            Our real estate software development process
                        </span>
                    </h2>
                </div>
                <div class="col-sm-12 mt-4 mb-4">
                    <p style="color: #215670; text-transform: capitalize">
                        At Excel IT AI, we strictly keep up with project
                        deadlines and always try to minimize development costs
                        where possible. This is achieved through the following
                        steps, which are a necessary part of our real estate
                        software services.
                    </p>
                </div>
            </div>
        </div>
    </section>
    <!-- custom software part end -->

    <!-- start of title content row  -->
    <!-- <div class="container row">
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Business analysis
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                We always conduct end-to-end market research at the early stage
                of custom real estate software development to determine the
                long-term prospects for the client's business development. This
                helps us get the idea of what the top product on the market
                looks, feels, and works like in order to implement the best
                practices.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Interface design
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                Solutions created for a wide target audience require a thorough
                approach to UI development. That’s why our UI designers often
                resort to the most accessible design templates that allow
                non-tech-savvy users to get a good hang of the end software.
                Along with this, we never neglect the personal client’s wishes,
                finding compromises between convenience and general vision of
                design.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                End-to-end testing
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                Our QA team of specialists will create a list of test cases that
                will cover the software code of the developed solution far and
                wide. This helps us minimize bugs and prevent many potential
                flaws, which means that you won’t have to deal with a barrage of
                user complaints.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Performance trials in the field
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                As part of our real estate services software development, we
                always check the created software in the real operating
                environment on all types of compatible devices. This eliminates
                any risks associated with software incompatibility, which is
                critical for such a responsible type of business as real estate.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Tech support
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                We strive for long-term relationships with our clients, offering
                post-releases tech support and advice. With us, you can always
                receive prompt technical maintenance for a launched solution or
                return it for the implementation of new features, integrations,
                and scaling.
            </p>
        </div>
    </div> -->
    <!-- end of title content row  -->

    <!-- ======= nine different sections Section ======= -->
    <section id="why-us" class="why-us section-bg px-5 py-5">
        <div class="container-fluid">
            <!-- first ROW strat -->
            <div class="row">
                <div class="col-md-4">
                    <div class="row">
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class="img-1st"
                                    src="../../../assets/img/bigdata.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <img
                                    src="../../../assets/img/border-1.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <div class="img-2nd center">
                                    <span>01</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class=""
                                    src="../../../assets/img/arrow-1.png"
                                    alt="Avatar"
                                />
                            </div>
                        </div>

                        <div class="content-box">
                            <h4 class="center">
                                <a href="" style="color: #92e3a9"
                                    >Business Analysis
                                </a>
                            </h4>
                            <p>
                                We always conduct end-to-end market research at
                                the early stage of custom real estate software
                                development to determine the long-term prospects
                                for the client's business development. This
                                helps us get the idea of what the top product on
                                the market looks, feels, and works like in order
                                to implement the best practices.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="row">
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class="img-1st"
                                    src="../../../assets/img/research.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <img
                                    src="../../../assets/img/border-1.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <div class="img-2nd center">
                                    <span>02</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="center">
                                <img
                                    class=""
                                    src="../../../assets/img/arrow-1.png"
                                    alt="Avatar"
                                />
                            </div>
                        </div>

                        <div class="content-box">
                            <h4 class="center">
                                <a href="" style="color: #92e3a9"
                                    >Interface design
                                </a>
                            </h4>
                            <p>
                                Solutions created for a wide target audience
                                require a thorough approach to UI development.
                                That’s why our UI designers often resort to the
                                most accessible design templates that allow
                                non-tech-savvy users to get a good hang of the
                                end software. Along with this, we never neglect
                                the personal client’s wishes, finding
                                compromises between convenience and general
                                vision of design.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="row">
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class="img-1st"
                                    src="../../../assets/img/blueprint.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <img
                                    src="../../../assets/img/border-1.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <div class="img-2nd center">
                                    <span>03</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="center">
                                <img
                                    src="../../../assets/img/arrow-1.png"
                                    alt="Avatar"
                                />
                            </div>
                        </div>

                        <div class="content-box wow slideInUp animated">
                            <h4 class="center">
                                <a href="" style="color: #92e3a9"
                                    >End-to-end testing
                                </a>
                            </h4>
                            <p>
                                Our QA team of specialists will create a list of
                                test cases that will cover the software code of
                                the developed solution far and wide. This helps
                                us minimize bugs and prevent many potential
                                flaws, which means that you won’t have to deal
                                with a barrage of user complaints.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- first ROW End -->

            <!-- third ROW strat -->
            <div class="row">
                <div class="col-md-4">
                    <div class="row">
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class="img-1st"
                                    src="../../../assets/img/deploy.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <img
                                    src="../../../assets/img/border-1.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <div class="img-2nd center">
                                    <span>04</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="center">
                                <img
                                    class=""
                                    src="../../../assets/img/arrow-1.png"
                                    alt="Avatar"
                                />
                            </div>
                        </div>

                        <div class="content-box">
                            <h4 class="center">
                                <a href="" style="color: #92e3a9"
                                    >Performance trials in the field
                                </a>
                            </h4>
                            <p>
                                As part of our real estate services software
                                development, we always check the created
                                software in the real operating environment on
                                all types of compatible devices. This eliminates
                                any risks associated with software
                                incompatibility, which is critical for such a
                                responsible type of business as real estate.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="row">
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class="img-1st"
                                    src="../../../assets/img/deploy.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <img
                                    src="../../../assets/img/border-1.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <div class="img-2nd center">
                                    <span>05</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="center">
                                <img
                                    class=""
                                    src="../../../assets/img/arrow-1.png"
                                    alt="Avatar"
                                />
                            </div>
                        </div>

                        <div class="content-box">
                            <h4 class="center">
                                <a href="" style="color: #92e3a9"
                                    >Tech support
                                </a>
                            </h4>
                            <p>
                                We strive for long-term relationships with our
                                clients, offering post-releases tech support and
                                advice. With us, you can always receive prompt
                                technical maintenance for a launched solution or
                                return it for the implementation of new
                                features, integrations, and scaling.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- third ROW End -->
        </div>
    </section>
    <!-- End nine different sections Section -->
</template>

<script>
import IndustriesLink from "../components/InductriesLink.vue";
export default {
    components: {
        IndustriesLink,
    },
    mounted() {
        document.title = "Real Estate | Excel IT AI";
        window.scrollTo({ top: 0, behavior: "smooth" });
    },
};
</script>

<style scoped>
.trasnport {
    background-image: url(../../../assets/images/industries/real_estate.jpg);
    width: 100%;
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
    height: 100%;
    position: relative;
}

.trasnport::before {
    position: absolute;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 100%;
    content: "";
    background: rgba(21, 37, 53, 0.8);
}
.trasnport .container {
    position: relative;
    z-index: 100;
}
li:hover {
    color: #fff;
}

.technology {
    /* background: linear-gradient(
        to bottom,
        rgba(52, 78, 99, 0.9),
        rgba(52, 78, 99)
    ); */
    background: #fff;
}
.ul_tag_style li a,
.breadcumpul li a {
    text-decoration: none !important;
    color: #215670 !important;
}
.ul_tag_style li a:hover,
.breadcumpul li a:hover {
    color: black !important;
    text-decoration: none !important;
}
</style>
