<template>
    <!-- industries top title section start -->
    <section class="health mt-5" style="padding: 50px 0px 50px 0px">
        <div class="container">
            <div class="row" style="text-align: center; padding-bottom: 50px">
                <h1 class="global-title">
                    <span class="rounded">Healthcare & Medicine</span>
                </h1>
            </div>
            <div class="row">
                <div class="col-md-6 py-4">
                    <h3
                        style="
                            text-align: center;
                            color: darkorange;
                            font-weight: bold;
                        "
                    >
                        Our healthcare application development services and
                        solutions
                    </h3>
                    <br />
                    <p
                        style="
                            text-align: justify;
                            color: white;
                            word-spacing: 0.2ch;
                            text-transform: capitalize;
                            line-height: 25px;
                        "
                    >
                        Modern software solutions for centralized data access,
                        monitoring, streaming help solve a wide range of tasks
                        for clinics that have been sticking to out-of-date
                        approaches for too long. Our experts are ready to take
                        on custom healthcare software development optimized
                        specifically for your medical organization. We guarantee
                        the maximum ROI thanks to the input of our specialists
                        and reduced human-factor risks in the long run. Our
                        healthcare software development company is driven by the
                        latest technology trends to improve all aspects of your
                        business.
                    </p>
                </div>
                <div class="col-md-2"></div>
                <div class="col-md-4">
                    <IndustriesLink></IndustriesLink>
                </div>
            </div>
        </div>
    </section>
    <!-- industries top title section end -->

    <!-- start of title row  -->
    <div class="container mt-5">
        <div
            class="col-md-12 my-5"
            style="
                display: flex;
                flex-direction: column;
                justify-content: center;
                align-items: center;
            "
        >
            <h2 class="global-title">
                <span class="rounded">Benefits</span>
            </h2>
            <p
                style="
                    color: #215670;
                    text-transform: capitalize;
                    font-family: sans-serif;
                "
            >
                of our healthcare software services
            </p>
        </div>
    </div>
    <!-- end of title row  -->

    <!-- start of title content row  -->
    <div class="container row">
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                In-depth medical expertise
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                The development of software for the healthcare niche requires a
                high level of expertise. We are proud to have assembled the best
                team in our medical software development company, which includes
                experts skillful in the latest developments in the field and
                know how to effectively use them in terms of a custom project.
                As a result, our clients receive not just a working solution but
                a product that can significantly boost the productivity of the
                organization's employees and reduce human risks.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Wide tech stack
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                We always keep our hand on the pulse of the healthcare IT
                market. This enables us to create products that help achieve
                advanced results in patient care, from submissions processing to
                remote monitoring of health indicators. We also back up our
                health software development with constantly updated means of
                security, ensuring full compliance with the policies and
                specifications of medical secrecy, GDPR, etc.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Focus on client’s success
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                We provide IT services for the development of custom medical
                software with a focus on client needs and business growth
                prospects. That is why many of our solutions are created using
                the latest technology trends. In this way, we offer long-term
                competitiveness of your business in the local market backed up
                by dedicated regular further support.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                100% reliability guarantee
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                We guarantee the reliability and safety of the project
                throughout the whole work cycle. That is why our team, in
                addition to narrow-profile developers in the healthcare niche,
                also has experienced testers and a whole department of QA
                specialists. We also take care of the maximum transparency of
                your investments, helping to both save the project budget and
                ensure the maximum return on investment.
            </p>
        </div>
    </div>
    <!-- end of title content row  -->

    <!--custom software  part start -->
    <section class="web_offer" style="font-family: sens-serif">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 mt-4 mb-4">
                    <h2
                        class="text-center global-title"
                        style="font-family: sens-serif"
                    >
                        <span class="rounded">
                            Our medical software development process
                        </span>
                    </h2>
                </div>
                <div class="col-sm-12 mt-4 mb-4">
                    <p style="color: #215670; text-transform: capitalize">
                        At Excel IT AI, we strictly keep up with project
                        deadlines and always try to minimize development costs
                        where possible. This is achieved through the following
                        steps, which are a necessary part of our healthcare
                        software services.
                    </p>
                </div>
            </div>
        </div>
    </section>
    <!-- custom software part end -->

    <!-- start of title content row  -->
    <!-- <div class="container row">
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Requirements gathering and analysis
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                First and foremost, you express your ideas, wishes, limitations,
                functional and non-functional requirements personally, in text
                or voice. Our Business Analysts check everything, and the
                project team identifies the best possible solution. This stage
                results in detailed project plans and SRS.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Business analysis
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                We always conduct end-to-end market research at the early stage
                of custom medical software development to determine the
                long-term prospects for the client's business development. This
                helps us get the idea of what the top product on the market
                looks, feels, and works like in order to implement the best
                practices.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Interface design
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                Solutions created for a wide target audience require a thorough
                approach to UI development. That’s why our UI designers often
                resort to the most accessible design templates that allow
                non-tech-savvy users to get a good hang of the end software.
                Along with this, we never neglect the personal client’s wishes,
                finding compromises between convenience and general vision of
                design.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                End-to-end testing
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                Our QA team of specialists will create a list of test cases that
                will cover the software code of the developed solution far and
                wide. This helps us minimize bugs and prevent many potential
                flaws, which means that you won’t have to deal with a barrage of
                user complaints.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Performance trials in the field
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                As part of our health services software development, we always
                check the created software in the real operating environment on
                all types of compatible devices. This eliminates any risks
                associated with software incompatibility, which is critical for
                such a responsible type of business as healthcare.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Tech support
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                We strive for long-term relationships with our clients, offering
                post-releases tech support and advice. With us, you can always
                receive prompt technical maintenance for a launched solution or
                return it for the implementation of new features, integrations,
                and scaling.
            </p>
        </div>
    </div> -->
    <!-- end of title content row  -->

    <!-- ======= nine different sections Section ======= -->
    <section id="why-us" class="why-us section-bg px-5 py-5">
        <div class="container-fluid">
            <!-- first ROW strat -->
            <div class="row">
                <div class="col-lg-4">
                    <div class="row">
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class="img-1st"
                                    src="../../../assets/img/bigdata.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <img
                                    src="../../../assets/img/border-1.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <div class="img-2nd center">
                                    <span>01</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class=""
                                    src="../../../assets/img/arrow-1.png"
                                    alt="Avatar"
                                />
                            </div>
                        </div>

                        <div class="content-box">
                            <h4 class="center">
                                <a href="" style="color: #92e3a9"
                                    >Business analysis
                                </a>
                            </h4>
                            <p>
                                We always conduct end-to-end market research at
                                the early stage of custom medical software
                                development to determine the long-term prospects
                                for the client's business development. This
                                helps us get the idea of what the top product on
                                the market looks, feels, and works like in order
                                to implement the best practices.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="row">
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class="img-1st"
                                    src="../../../assets/img/research.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <img
                                    src="../../../assets/img/border-1.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <div class="img-2nd center">
                                    <span>02</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="center">
                                <img
                                    class=""
                                    src="../../../assets/img/arrow-1.png"
                                    alt="Avatar"
                                />
                            </div>
                        </div>

                        <div class="content-box">
                            <h4 class="center">
                                <a href="" style="color: #92e3a9"
                                    >Interface design
                                </a>
                            </h4>
                            <p>
                                Solutions created for a wide target audience
                                require a thorough approach to UI development.
                                That’s why our UI designers often resort to the
                                most accessible design templates that allow
                                non-tech-savvy users to get a good hang of the
                                end software. Along with this, we never neglect
                                the personal client’s wishes, finding
                                compromises between convenience and general
                                vision of design.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="row">
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class="img-1st"
                                    src="../../../assets/img/blueprint.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <img
                                    src="../../../assets/img/border-1.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <div class="img-2nd center">
                                    <span>03</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="center">
                                <img
                                    src="../../../assets/img/arrow-1.png"
                                    alt="Avatar"
                                />
                            </div>
                        </div>

                        <div class="content-box wow slideInUp animated">
                            <h4 class="center">
                                <a href="" style="color: #92e3a9">
                                    End-to-end testing
                                </a>
                            </h4>
                            <p>
                                Our QA team of specialists will create a list of
                                test cases that will cover the software code of
                                the developed solution far and wide. This helps
                                us minimize bugs and prevent many potential
                                flaws, which means that you won’t have to deal
                                with a barrage of user complaints.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- first ROW End -->

            <!-- third ROW strat -->
            <div class="row">
                <div class="col-lg-4">
                    <div class="row">
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class="img-1st"
                                    src="../../../assets/img/deploy.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <img
                                    src="../../../assets/img/border-1.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <div class="img-2nd center">
                                    <span>04</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="center">
                                <img
                                    class=""
                                    src="../../../assets/img/arrow-1.png"
                                    alt="Avatar"
                                />
                            </div>
                        </div>

                        <div class="content-box">
                            <h4 class="center">
                                <a href="" style="color: #92e3a9"
                                    >Performance trials in the field
                                </a>
                            </h4>
                            <p>
                                As part of our health services software
                                development, we always check the created
                                software in the real operating environment on
                                all types of compatible devices. This eliminates
                                any risks associated with software
                                incompatibility, which is critical for such a
                                responsible type of business as healthcare.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="row">
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class="img-1st"
                                    src="../../../assets/img/deploy.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <img
                                    src="../../../assets/img/border-1.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <div class="img-2nd center">
                                    <span>05</span>
                                </div>
                            </div>
                        </div>
                        <!-- <div class="col-md-6">
                            <div class="center">
                                <img
                                    class=""
                                    src="../../../assets/img/arrow-1.png"
                                    alt="Avatar"
                                />
                            </div>
                        </div> -->

                        <div class="content-box">
                            <h4 class="center">
                                <a href="" style="color: #92e3a9"
                                    >Tech support
                                </a>
                            </h4>
                            <p>
                                We strive for long-term relationships with our
                                clients, offering post-releases tech support and
                                advice. With us, you can always receive prompt
                                technical maintenance for a launched solution or
                                return it for the implementation of new
                                features, integrations, and scaling.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- third ROW End -->
        </div>
    </section>
    <!-- End nine different sections Section -->
</template>

<script>
import IndustriesLink from "../components/InductriesLink.vue";
import "../../../assets/css/bootstrap5.min.css";
export default {
    components: {
        IndustriesLink,
    },
    mounted() {
        document.title = "HEALTH | Excel IT AI";
        window.scrollTo({ top: 0, behavior: "smooth" });
    },
};
</script>

<style scoped>
.health {
    background-image: url(../../../assets/images/health.jpg);
    width: 100%;
    height: 100%;
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
    position: relative;
}
.health::before {
    position: absolute;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 100%;
    content: "";
    background: rgba(21, 37, 53, 0.8);
}
.health .container {
    position: relative;
    z-index: 100;
}
li:hover {
    color: rgb(0, 0, 0);
}

h1 {
    color: rgb(32, 128, 104);
}
h4,
li h5 {
    color: rgb(20, 167, 130);
}
p,
a {
    color: #fff;
}
.health-content {
    /* background: linear-gradient(
        to bottom,
        rgba(52, 78, 99, 0.9),
        rgba(52, 78, 99)
    ); */
    background: #fff;
}
.ul_tag_style li a,
.breadcumpul li a {
    text-decoration: none !important;
    color: #215670 !important;
}
.ul_tag_style li a:hover,
.breadcumpul li a:hover {
    color: black !important;
    text-decoration: none !important;
}

.img-1st {
    border-radius: 50%;
    height: 75px;
    width: 75px;
    border-style: dotted;
    border-width: 2px;
    border-color: #92e3a9;
    text-align: center;
    padding: 1px;
    transition: 0.3s;
}
.img-2nd {
    border-radius: 50%;
    height: 50px;
    width: 50px;
    /* border-style: solid; */
    /* border-width: 1px; */
    /* border-color: #fb6064; */
    text-align: center;
    padding-top: 4px;
}
.img-2nd span {
    position: relative;
    display: inline-block;
    width: 40px;
    height: 40px;
    line-height: 40px;
    font-size: 15px;
    font-family: "Muli", Sans-serif;
    font-weight: 700;
    color: #fff;
    border-radius: 50%;
    background-color: red;
    border-color: floralwhite;
    border: 2px;
}
.center {
    display: block;
    margin-left: auto;
    margin-right: auto;
    width: 50%;
    text-align: center;
    /* border: 1px solid; */
    /* border: 1px solid red; */
}

.img-1st:hover {
    background-color: #92e3a9;
    cursor: pointer;
}

.content-box {
    height: auto;
    width: 300px;
    position: relative;
    display: block;
    background: linear-gradient(to bottom, rgb(65, 95, 205), rgb(68, 144, 188));
    padding: 47px 30px 43px 30px;
    border-radius: 30px;
    margin-left: 10px;
    box-shadow: 0 10px 30px rgb(0 0 0 / 10%);
    margin-top: 50px;
    margin-bottom: 50px;
    border: 10px solid #92e3a9;
    /* border: 10px solid #215670; */
}
.content-box h4 a {
    font-size: 1.3rem !important;
}

.content-box p {
    color: #fff;
}
</style>
