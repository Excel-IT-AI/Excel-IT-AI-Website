<template>
    <!-- web about part start -->
    <section class="mt-5 pt-5">
        <div class="container">
            <div class="row" style="text-align: center; padding-bottom: 50px">
                <h2 class="global-title">
                    <span class="rounded">UI/UX DESIGN</span>
                </h2>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="web_about">
                        <p
                            style="
                                color: #152535;
                                text-align: justify;
                                letter-spacing: 0.1ch;
                            "
                        >
                            UI/UX design services include two critical aspects:
                            user interface and user experience. The user
                            interface or UI is all about the visual look of your
                            application or website. All your customers interact
                            with the same interface that acts as a bridge
                            between people and your services. Users interact
                            with the software through interfaces, so it’s
                            essential to make everything beautiful, clean,
                            simple, and understandable. Our UI/UX design studio
                            knows how to create cool interfaces. User experience
                            is a more comprehensive term that includes UI. It
                            focuses on general interactions, ways in which
                            customers access your solutions, move through them.
                            Robust UX design helps you to guide users, ensure
                            that they can find what they need quickly and
                            smoothly. UX things are unique for each user. Hence,
                            you want to keep experience responsive and
                            personalized. Overall, our UI/UX design company
                            often combines these two parts as they’re highly
                            interconnected. You can get various tasks completed
                            by our team of professional designers in this area:
                        </p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div
                        id="carouselExampleControls"
                        class="carousel slide"
                        data-bs-ride="carousel"
                    >
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <img
                                    src="../../../assets/images/services/uiux_app/u1.jpg"
                                    class="d-block w-100"
                                    alt="..."
                                />
                            </div>
                            <div class="carousel-item">
                                <img
                                    src="../../../assets/images/services/uiux_app/u2.jpg"
                                    class="d-block w-100"
                                    alt="..."
                                />
                            </div>
                            <div class="carousel-item">
                                <img
                                    src="../../../assets/images/services/uiux_app/u3.png"
                                    class="d-block w-100"
                                    alt="..."
                                />
                            </div>
                        </div>
                        <button
                            class="carousel-control-prev"
                            type="button"
                            data-bs-target="#carouselExampleControls"
                            data-bs-slide="prev"
                        >
                            <span
                                class="carousel-control-prev-icon"
                                aria-hidden="true"
                            ></span>
                            <span class="visually-hidden">Previous</span>
                        </button>
                        <button
                            class="carousel-control-next"
                            type="button"
                            data-bs-target="#carouselExampleControls"
                            data-bs-slide="next"
                        >
                            <span
                                class="carousel-control-next-icon"
                                aria-hidden="true"
                            ></span>
                            <span class="visually-hidden">Next</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- web about part start -->

    <!-- start of title row  -->
    <div class="container mt-5">
        <div
            class="col-md-12 my-5"
            style="display: flex; justify-content: center; align-items: center"
        >
            <h2 class="global-title">
                <span class="rounded">Benefits</span>
            </h2>
        </div>
    </div>
    <!-- end of title row  -->

    <!-- start of title content row  -->
    <div class="container row">
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                from UI/UX design agency
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                Professional consulting and all other UI/UX design services can
                change the game for your brand. Being the main connector between
                customers and business offers, design defines how people will
                perceive you. Provide a clear interface with simple user
                journeys, and you will attract and retain customers much more
                efficiently. Other benefits provided by a sophisticated UI/UX
                design agency include:
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Perfect personalization
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                Thanks to tailored designs, you show your commitment to all
                clients. We develop interfaces for various users, including
                people with disabilities.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Reduced risk of failure
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                With initial research from a UX design company, you can test
                user flows and features without investing a lot of money or
                time.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Stand out from the crowd
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                Good solutions engage and convert. What’s more important, users
                remember them and, respectively, your brand.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Ultimate acquisition and retention
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                People appreciate predictive and user-centered solutions. It’s
                simpler to understand your audience thanks to our UI/UX design
                studio.
            </p>
        </div>
    </div>
    <!-- end of title content row  -->

    <!-- web offer part start -->
    <section class="web_offer">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 mt-4 mb-4">
                    <h2 class="text-center global-title">
                        <span class="rounded"> What We Offer</span>
                    </h2>
                </div>
            </div>
            <div class="row mt-4" style="padding-bottom: 50px">
                <div class="col-md-4" data-aos="flip-left">
                    <div class="offer">
                        <span class="elementor-icon-list-icon">
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fab fa-xbox"
                            ></i>
                            UI/UX for cross-platform solutions</span
                        >
                        <br />
                    </div>
                </div>
                <div class="col-md-4" data-aos="flip-left">
                    <div class="offer">
                        <span class="elementor-icon-list-icon">
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fas fa-mobile"
                            ></i>
                            UI/UX for mobile apps</span
                        >
                        <br />
                    </div>
                </div>

                <div class="col-md-4" data-aos="flip-left">
                    <div class="offer">
                        <span
                            class="elementor-icon-list-icon"
                            style="margin-right: 10px"
                        >
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fas fa-quidditch"
                            ></i>
                            UI/UX for websites
                        </span>
                        <br />
                    </div>
                </div>

                <div class="col-md-4" data-aos="flip-left">
                    <div class="offer">
                        <br />
                        <span class="elementor-icon-list-icon">
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fas fa-crop-alt"
                            ></i>
                            UI/UX redesign and optimization</span
                        >
                        <br />
                    </div>
                </div>
                <div class="col-md-12 py-4">
                    There’s only one chance to make a first impression. And you
                    will need flawless UX design services to attract a user.
                    From simple mobile applications to comprehensive enterprise
                    banking platforms, all digital solutions require solid and
                    user-friendly interfaces to ensure user satisfaction. Our UX
                    design company handles both separate projects and parts of
                    broader offerings, combined with software development,
                    optimization, or migration. With us, you get tailored,
                    responsive designs that meet your business goals and boost
                    customer loyalty. DICEUS isn’t only a UI/UX design agency
                    but a trustworthy partner for your digital transformation.
                    So don’t hesitate to ask us about the services and processes
                    you’re interested in.
                </div>
            </div>
        </div>
    </section>
    <!-- web offer part end -->

    <section class="web_offer" style="font-family: sens-serif">
        <div class="container">
            <div class="row" style="padding-bottom: 50px">
                <div class="col-md-12">
                    <!-- header section  -->
                    <div class="row">
                        <div
                            class="
                                col-sm-12
                                d-flex
                                justify-content-center
                                flex-column
                                align-items-center
                                mt-4
                                mb-4
                            "
                        >
                            <h3
                                class="text-capitalize"
                                style="
                                    color: chocolate;
                                    font-family: sens-serif;
                                "
                            >
                                what impacts your project duration
                            </h3>
                            <p style="color: #215670">
                                The schedule of app development services depends
                                heavily on some critical factors
                            </p>
                        </div>
                    </div>
                    <!-- end of header section  -->
                    <!-- list body  -->

                    <div class="row">
                        <div class="col-md-6 d-flex justify-content-center">
                            <div class="offer">
                                <span class="elementor-icon-list-icon">
                                    <i
                                        style="color: darkorange"
                                        aria-hidden="true"
                                        class="fab fa-xbox"
                                    ></i>

                                    Project requirements</span
                                >
                                <br />
                                <span class="elementor-icon-list-icon">
                                    <i
                                        style="color: darkorange"
                                        aria-hidden="true"
                                        class="fas fa-calendar"
                                    ></i>
                                    Expected deadlines</span
                                >
                            </div>
                        </div>
                        <div class="col-md-6 d-flex justify-content-center">
                            <div class="offer">
                                <span
                                    class="elementor-icon-list-icon"
                                    style="margin-right: 10px"
                                >
                                    <i
                                        style="color: rgb(209, 138, 30)"
                                        aria-hidden="true"
                                        class="fas fa-drafting-compass"
                                    ></i>
                                    Team composition
                                </span>
                                <br />
                                <span class="elementor-icon-list-icon">
                                    <i
                                        style="color: darkorange"
                                        aria-hidden="true"
                                        class="fas fa-tools"
                                    ></i>
                                    The available technologies and
                                    platforms</span
                                >
                                <br />
                                <span class="elementor-icon-list-icon">
                                    <i
                                        style="color: darkorange"
                                        aria-hidden="true"
                                        class="fab fa-uncharted"
                                    ></i>
                                    Assistance with publications in app
                                    stores</span
                                >
                            </div>
                        </div>
                    </div>

                    <!-- end of list body  -->
                </div>

                <!--  end dev  -->
            </div>
        </div>
    </section>

    <!-- our teach stack part start -->
    <section class="web_offer">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 mt-4 mb-4">
                    <h2
                        class="text-center global-title"
                        style="font-family: sans-serif"
                    >
                        <span class="rounded">Our Tech Stack</span>
                    </h2>
                </div>
            </div>
            <div class="row container">
                <div class="col-md-12 container">
                    <div class="container row">
                        <div class="row" style="padding-bottom: 50px">
                            <div class="col-md-6">
                                <div
                                    class="
                                        offer
                                        d-flex
                                        justify-content-center
                                        flex-column
                                        align-items-end
                                    "
                                >
                                    <span
                                        class="elementor-icon-list-icon p-3"
                                        style="color: black"
                                    >
                                        <img
                                            src="/images/uiux_service/adobexd.png"
                                            width="50"
                                            height="50"
                                            class="my-3"
                                        />
                                        Adobe XD</span
                                    >
                                    <br />
                                    <span
                                        class="elementor-icon-list-icon p-3"
                                        style="color: black"
                                    >
                                        <img
                                            src="/images/uiux_service/figma.png"
                                            width="50"
                                            height="50"
                                            class="my-3"
                                        />
                                        Figma
                                    </span>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div
                                    class="
                                        offer
                                        d-flex
                                        justify-content-center
                                        align-items-start
                                        flex-column
                                    "
                                >
                                    <span
                                        class="elementor-icon-list-icon p-3"
                                        style="margin-right: 10px; color: black"
                                    >
                                        <img
                                            src="/images/uiux_service/sketch.png"
                                            width="50"
                                            height="50"
                                            class="my-3"
                                        />
                                        Sketch
                                    </span>
                                    <br />
                                    <span
                                        class="elementor-icon-list-icon p-3"
                                        style="margin-right: 10px; color: black"
                                    >
                                        <img
                                            src="/images/uiux_service/zeplin.png"
                                            width="50"
                                            height="50"
                                            class="my-3"
                                        />
                                        Zeplin
                                    </span>
                                    <br />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--  our teach stack  part end -->
    <!-- Technologies  uses part start -->
    <!-- <section>
        <div class="container">
            <div class="row">
                <div class="col-sm-12 mt-4 mb-4">
                    <h2 class="text-center global-title" style="color: #215670">
                        <span class="rounded">Design using Tools</span>
                    </h2>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="owl-carousel owl-theme owl-loaded pb-3">
                        <div class="owl-stage-outer">
                            <div class="owl-stage">
                                <div class="owl-item">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/service_slider_logo/adobe_ai.png"
                                            /></a>
                                        </div>
                                        <div class="col-md-3 d-none d-md-block">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/service_slider_logo/figma_logo.png"
                                            /></a>
                                        </div>
                                        <div class="col-md-3 d-none d-md-block">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/service_slider_logo/photo_shop_logo.png"
                                            /></a>
                                        </div>
                                        <div class="col-md-3 d-none d-md-block">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/service_slider_logo/xd_logo.png"
                                            /></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="owl-item">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/service_slider_logo/adobe_ai.png"
                                            /></a>
                                        </div>
                                        <div class="col-md-3 d-none d-md-block">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/service_slider_logo/figma_logo.png"
                                            /></a>
                                        </div>
                                        <div class="col-md-3 d-none d-md-block">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/service_slider_logo/photo_shop_logo.png"
                                            /></a>
                                        </div>
                                        <div class="col-md-3 d-none d-md-block">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/service_slider_logo/xd_logo.png"
                                            /></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="owl-item">
                                    <div class="row">
                                        <div class="col-md-3 d-none d-md-block">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/service_slider_logo/adobe_ai.png"
                                            /></a>
                                        </div>
                                        <div class="col-md-3 d-none d-md-block">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/service_slider_logo/figma_logo.png"
                                            /></a>
                                        </div>
                                        <div class="col-md-3">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/service_slider_logo/photo_shop_logo.png"
                                            /></a>
                                        </div>
                                        <div class="col-md-3 d-none d-md-block">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/service_slider_logo/xd_logo.png"
                                            /></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="owl-item">
                                    <div class="row">
                                        <div class="col-md-3 d-none d-md-block">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/service_slider_logo/adobe_ai.png"
                                            /></a>
                                        </div>
                                        <div class="col-md-3 d-none d-md-block">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/service_slider_logo/figma_logo.png"
                                            /></a>
                                        </div>
                                        <div class="col-md-3 d-none d-md-block">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/service_slider_logo/photo_shop_logo.png"
                                            /></a>
                                        </div>
                                        <div class="col-md-3">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/service_slider_logo/xd_logo.png"
                                            /></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section> -->
    <!-- Technologies  uses part end -->

    <!--custom software  part start -->
    <section class="web_offer" style="font-family: sens-serif">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 mt-4 mb-4">
                    <h2
                        class="text-center global-title"
                        style="font-family: sens-serif"
                    >
                        <span class="rounded">
                            Our UI/UX development process
                        </span>
                    </h2>
                </div>
                <div class="col-sm-12 mt-4 mb-4">
                    <p
                        style="
                            color: #215670;
                            text-transform: capitalize;
                            font-family: sans-serif;
                        "
                    >
                        In UI design services, we apply our core standard-driven
                        lifecycle. The service itself is close to the business
                        analysis stage with requirements elicitation,
                        interviewing, and understanding needs. Often, it’s a
                        part of a larger general development flow. However, by
                        ordering our UI/UX consulting and other offerings, you
                        always get similar time-proven approaches even at
                        smaller scales. We move through core stages to provide
                        the best results
                    </p>
                </div>
            </div>
        </div>
    </section>
    <!-- custom software part end -->

    <!-- ======= nine different sections Section ======= -->
    <section id="why-us" class="why-us section-bg px-5 py-5">
        <div class="container-fluid">
            <!-- first ROW strat -->
            <div class="row">
                <div class="col-md-4">
                    <div class="row">
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class="img-1st"
                                    src="../../../assets/img/bigdata.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <img
                                    src="../../../assets/img/border-1.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <div class="img-2nd center">
                                    <span>01</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class=""
                                    src="../../../assets/img/arrow-1.png"
                                    alt="Avatar"
                                />
                            </div>
                        </div>

                        <div class="content-box">
                            <h4 class="center">
                                <a href="" style="color: #92e3a9"
                                    >Discovery Phase
                                </a>
                            </h4>
                            <p>
                                Discovery is a preliminary phase in the UX
                                design process that involves researching the
                                scope and problems. The very first step is to
                                define your requirements and the purpose of your
                                project. Various types of stakeholders'
                                interviews allow our UI design company to get
                                all the necessary information to start working.
                                Here, we analyze the key business objectives of
                                the organization, individuals, or teams. Another
                                area of analysis is data and insights about how
                                problems affect users, as well as the solutions
                                users have already tried.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="row">
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class="img-1st"
                                    src="../../../assets/img/research.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <img
                                    src="../../../assets/img/border-1.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <div class="img-2nd center">
                                    <span>02</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="center">
                                <img
                                    class=""
                                    src="../../../assets/img/arrow-1.png"
                                    alt="Avatar"
                                />
                            </div>
                        </div>

                        <div class="content-box wow slideInUp animated">
                            <h4 class="center">
                                <a
                                    href=""
                                    style="color: #92e3a9; margin-left: -2rem"
                                    >Documentation
                                </a>
                            </h4>
                            <p>
                                After defining needs and goals, we start
                                transferring received business and technical
                                requirements into a future product. Thus, you
                                get user itories, user personas, and storyboards
                                that help to understand user experience better
                                and align it with the products/services. Such
                                boards are available for each use case, so you
                                can be sure of user-centered design. At this
                                stage, the main goal is to finalize future views
                                of how the product will work and describe all
                                the related processes.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="row">
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class="img-1st"
                                    src="../../../assets/img/blueprint.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <img
                                    src="../../../assets/img/border-1.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <div class="img-2nd center">
                                    <span>03</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="center">
                                <img
                                    src="../../../assets/img/arrow-1.png"
                                    alt="Avatar"
                                />
                            </div>
                        </div>

                        <div class="content-box wow slideInUp animated">
                            <h4 class="center">
                                <a href="" style="color: #92e3a9"
                                    >UX Stage-Functionality
                                </a>
                            </h4>
                            <p>
                                The next step is to provide actual UI design
                                services. Firstly, we create specific blueprints
                                or skeletons of your solution: Ul/UX wireframes.
                                These screens include simple blocks without
                                graphics. They help to combine all elements to
                                show basic structures. As well, you can get
                                design prototypes through an additional stage.
                                Prototypes are simulations of real products,
                                they show how a site or an app works, how the
                                final design flows.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- first ROW End -->

            <!-- third ROW strat -->
            <div class="row">
                <div class="col-md-4">
                    <div class="row">
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class="img-1st"
                                    src="../../../assets/img/deploy.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <img
                                    src="../../../assets/img/border-1.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <div class="img-2nd center">
                                    <span>04</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="center">
                                <img
                                    class=""
                                    src="../../../assets/img/arrow-1.png"
                                    alt="Avatar"
                                />
                            </div>
                        </div>

                        <div class="content-box">
                            <h4 class="center">
                                <a href="" style="color: #92e3a9"
                                    >UI Design-visuals</a
                                >
                            </h4>
                            <p>
                                Further,we add visual elements and interactions
                                to wireframes. At this stage, you can get UI
                                design mockups with fonts, styles, and corporate
                                identity to check how your solution will look
                                and feel for users. Also, we apply animation to
                                interface to make the product stand out as much
                                as possible and improve the products' usability
                                within the animation. After all visuals are
                                approved, we collect all of them in the UI Kit —
                                UX/UI document that describes all contents of
                                the system, their style, and behavior. This
                                document allows us to transfer designs for
                                further development faster and easier.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="row">
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class="img-1st"
                                    src="../../../assets/img/deploy.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <img
                                    src="../../../assets/img/border-1.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <div class="img-2nd center">
                                    <span>05</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="center">
                                <img
                                    class=""
                                    src="../../../assets/img/arrow-1.png"
                                    alt="Avatar"
                                />
                            </div>
                        </div>

                        <div class="content-box">
                            <h4 class="center">
                                <a href="" style="color: #92e3a9">Testing </a>
                            </h4>
                            <p>
                                You can request any changes or updates to the
                                presented Ul/UX design prototypes and mockups.
                                The testing stage continues until no further
                                user experience issues can be identified. At
                                this stage, our UI design company controls that
                                main usability heuristics are counted (for
                                instance, consistency, system status visibility,
                                error prevention). The same is true for user
                                testing. In addition, depending on the needs, we
                                can count ROI (return on investment). This is
                                about the balance of the income (return) and
                                economy (investment). Positive ROI gives you a
                                green signal to grow.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="row">
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class="img-1st"
                                    src="../../../assets/img/deploy.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <img
                                    src="../../../assets/img/border-1.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <div class="img-2nd center">
                                    <span>06</span>
                                </div>
                            </div>
                        </div>

                        <div class="content-box">
                            <h4 class="center">
                                <a href="" style="color: #92e3a9"
                                    >Support and changes
                                </a>
                            </h4>
                            <p>
                                After all wireframes, mockups, and prototypes
                                are approved, you can get your Ul/UX solutions.
                                We hand over all pages and screens with the
                                required elements to our expert frontend
                                developers. They ensure that everything looks
                                exactly as designed. In addition, we can prepare
                                UI Kits for you, so you can get all the elements
                                in addition to the ready interface. With us, you
                                get proactive support at all stages, including
                                coding and deployment of the ready designs or
                                interfaces. We're ready to fix things, handle
                                the next Ul/UX consulting stages, and make UI/UX
                                solutions even better.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- third ROW End -->
        </div>
    </section>
    <!-- End nine different sections Section -->

    <div class="container">
        <div class="row">
            <div
                class="
                    col-md-12
                    d-flex
                    justify-content-center
                    align-items-center
                "
            >
                <p class="get_quote_button">
                    <router-link :to="{ name: 'Contact' }" class=""
                        >get a free quote now</router-link
                    >
                </p>
            </div>
        </div>
    </div>
</template>

<script>
import SliderFont from "../../../assets/js/slider_font";
import OwlCarousel from "../../../assets/js/owl.carousel.min.js";
export default {
    mounted() {
        OwlCarousel();
        SliderFont();
        document.title = "UI/UX DESIGN COURSE | Excel IT AI";
        window.scrollTo({ top: 0, behavior: "smooth" });
    },
};
</script>

<style scoped>
@import "../../../assets/css/bootstrap5.min.css";
@import "../css/home_slider_trusted_company.css";
ul {
    margin: 0;
    padding: 0;
    list-style: none;
}

a {
    text-decoration: none;
}

p {
    font-size: 18px;
    line-height: 1.2;
}

h1,
h2,
h3,
h4,
h5,
h6 {
    font-family: "Courier New", Courier, monospace;
    font-weight: 700;
    line-height: 1.2;
}

h1 {
    font-size: 3.375rem;
}

h2 {
    font-size: 2rem;
}
.carousel-item img {
    border-radius: 10px;
}

.thumbnail {
    width: 100%;
    height: 100%;
}
.thumbnail img {
    width: 150px !important;
    height: 150px !important;
    object-fit: fill;
}

.elementor-icon-list-icon {
    color: black !important;
}

.img-1st {
    border-radius: 50%;
    height: 75px;
    width: 75px;
    border-style: dotted;
    border-width: 2px;
    border-color: #92e3a9;
    text-align: center;
    padding: 1px;
    transition: 0.3s;
}
.img-2nd {
    border-radius: 50%;
    height: 50px;
    width: 50px;
    /* border-style: solid; */
    /* border-width: 1px; */
    /* border-color: #fb6064; */
    text-align: center;
    padding-top: 4px;
}
.img-2nd span {
    position: relative;
    display: inline-block;
    width: 40px;
    height: 40px;
    line-height: 40px;
    font-size: 15px;
    font-family: "Muli", Sans-serif;
    font-weight: 700;
    color: #fff;
    border-radius: 50%;
    background-color: red;
    border-color: floralwhite;
    border: 2px;
}
.center {
    display: block;
    margin-left: auto;
    margin-right: auto;
    width: 50%;
    text-align: center;
    /* border: 1px solid; */
    /* border: 1px solid red; */
}

.img-1st:hover {
    background-color: #92e3a9;
    cursor: pointer;
}

.content-box {
    height: auto;
    width: 300px;
    position: relative;
    display: block;
    background: linear-gradient(to bottom, rgb(65, 95, 205), rgb(68, 144, 188));
    padding: 47px 30px 43px 30px;
    border-radius: 30px;
    margin-left: 10px;
    box-shadow: 0 10px 30px rgb(0 0 0 / 10%);
    margin-top: 50px;
    margin-bottom: 50px;
    border: 10px solid #92e3a9;
    /* border: 10px solid #215670; */
}

.content-box h4 a {
    font-size: 1.3rem !important;
}
.content-box p {
    color: #fff;
    /* text-align: justify; */
    word-spacing: 0.2ch !important;
    letter-spacing: 0.1ch;
}
</style>
