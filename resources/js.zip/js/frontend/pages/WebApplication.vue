<template>
    <!-- web about part start -->
    <section class="mt-5 pt-5">
        <div class="container">
            <div class="row" style="text-align: center; padding-bottom: 50px">
                <h2 class="global-title">
                    <span class="rounded">Web Application</span>
                </h2>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="web_about">
                        <p
                            style="
                                color: #152535;
                                text-align: justify;
                                letter-spacing: 0.1ch;
                            "
                        >
                            Talking about custom web application development, we
                            mean a whole range of distinct services. They
                            include enterprise and customer research, design
                            wireframing and prototyping, architecture planning,
                            frontend and backend coding, optimization,
                            maintenance, DevOps, and so on. Web app development
                            helps people learn more about your company, check
                            the services and products, contact your team,
                            interact with various solutions: catalogs, order
                            forms, videos, etc. If you need a new tool, want to
                            improve an existing app, or require thorough
                            research, we’re ready to help with all these web
                            application development services. We provide custom
                            web app development, cross-platform development,
                            design, web consulting, legacy modernization, system
                            integration, and lifelong support. You can quickly
                            get the solution you need, from simple websites to
                            advanced dynamic web apps with the tailored client-
                            and server-side modules. Don’t hesitate to ask us
                            about our web application development company if you
                            have any questions or ideas to discuss.
                        </p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div
                        id="carouselExampleControls"
                        class="carousel slide"
                        data-bs-ride="carousel"
                    >
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <img
                                    src="../../../assets/images/services/web_app/web1.jpg"
                                    class="d-block w-100"
                                    alt="..."
                                />
                            </div>
                            <div class="carousel-item">
                                <img
                                    src="../../../assets/images/services/web_app/web2.jpg"
                                    class="d-block w-100"
                                    alt="..."
                                />
                            </div>
                            <div class="carousel-item">
                                <img
                                    src="../../../assets/images/services/web_app/web3.jpg"
                                    class="d-block w-100"
                                    alt="..."
                                />
                            </div>
                        </div>
                        <button
                            class="carousel-control-prev"
                            type="button"
                            data-bs-target="#carouselExampleControls"
                            data-bs-slide="prev"
                        >
                            <span
                                class="carousel-control-prev-icon"
                                aria-hidden="true"
                            ></span>
                            <span class="visually-hidden">Previous</span>
                        </button>
                        <button
                            class="carousel-control-next"
                            type="button"
                            data-bs-target="#carouselExampleControls"
                            data-bs-slide="next"
                        >
                            <span
                                class="carousel-control-next-icon"
                                aria-hidden="true"
                            ></span>
                            <span class="visually-hidden">Next</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- web about part start -->

    <!-- start of title row  -->
    <div class="container mt-5">
        <div
            class="col-md-12 my-5"
            style="display: flex; justify-content: center; align-items: center"
        >
            <h2 class="global-title">
                <span class="rounded">Benefits</span>
            </h2>
        </div>
    </div>
    <!-- end of title row  -->

    <!-- start of title content row  -->
    <div class="container row">
        <div class="col-md-12">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                from our web app development services
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                Web app development services are complex, but they focus on your
                end goals always. We value your time, so all our services are
                client-centered. We offer custom cooperation models with
                changeable schedules, engagement and payment schemes. Through
                cooperation with our custom web application development company,
                you get the most critical enterprise values:
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Complete understanding of your needs
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                In-depth business analysis helps us reveal your requirements,
                identify business gaps, and deliver software that fills them.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Fast and responsive solutions
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                You will get an app with UI and UX compatible with various
                platforms and browsers. We use advanced tools to minimize
                response time.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Reduction of development expenses
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                Eventually, you cut development time and costs thanks to custom
                Agile approaches. We work for the result, not hours.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Transparent project control
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                Using our monitoring service called Customer Portal, you can
                check all data about your projects, manage changes, and
                communicate with us.
            </p>
        </div>
    </div>
    <!-- end of title content row  -->

    <!-- web offer part start -->
    <section class="web_offer">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 mt-4 mb-4">
                    <h2
                        class="text-center global-title"
                        style="font-family: sans-serif"
                    >
                        <span class="rounded">What We Offer</span>
                    </h2>
                </div>
            </div>
            <div class="row" style="padding-bottom: 50px">
                <div class="col-md-4" data-aos="flip-left">
                    <div class="offer">
                        <span
                            class="elementor-icon-list-icon"
                            style="color: black"
                        >
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fab fa-xbox"
                            ></i>
                            Website and web app development</span
                        >
                        <br />
                        <span
                            class="elementor-icon-list-icon"
                            style="color: black"
                        >
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fas fa-calendar"
                            ></i>
                            CRM and CMS solutions</span
                        >
                        <br />
                        <span
                            class="elementor-icon-list-icon"
                            style="margin-right: 10px; color: black"
                        >
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fas fa-drafting-compass"
                            ></i>
                            Enterprise solution architecture
                        </span>
                        <br />
                        <span
                            class="elementor-icon-list-icon"
                            style="color: black"
                        >
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fas fa-dungeon"
                            ></i>
                            Open-source development</span
                        >
                    </div>
                </div>
                <div class="col-md-4" data-aos="flip-up">
                    <div class="offer">
                        <span
                            class="elementor-icon-list-icon"
                            style="color: black"
                        >
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fas fa-city"
                            ></i>
                            Cross-platform development</span
                        >
                        <br />
                        <span
                            class="elementor-icon-list-icon"
                            style="color: black"
                        >
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fas fa-cross"
                            ></i>
                            Testing and quality assurance</span
                        >
                        <br />
                        <span
                            class="elementor-icon-list-icon"
                            style="color: black"
                        >
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fas fa-cog"
                            ></i>
                            SaaS development</span
                        >
                    </div>
                </div>
                <div class="col-md-4" data-aos="flip-right">
                    <div class="offer">
                        <span
                            class="elementor-icon-list-icon"
                            style="color: black"
                        >
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fas fa-torah"
                            ></i>
                            GUI and UI/UX design
                        </span>
                        <br />
                        <span
                            class="elementor-icon-list-icon"
                            style="color: black"
                        >
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fas fa-ethernet"
                            ></i>
                            Progressive web app development</span
                        >
                        <br />
                        <span
                            class="elementor-icon-list-icon"
                            style="color: black"
                        >
                            <i
                                style="color: darkorange"
                                aria-hidden="true"
                                class="fas fa-compress-arrows-alt"
                            ></i>
                            Software optimization and migration</span
                        >
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- web offer part end -->
    <!-- our teach stack part start -->
    <section class="web_offer">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 mt-4 mb-4">
                    <h2
                        class="text-center global-title"
                        style="font-family: sans-serif"
                    >
                        <span class="rounded">Our Tech Stack</span>
                    </h2>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="container row">
                        <div class="col-md-12">
                            <h3
                                class="text-capitalize"
                                style="
                                    color: chocolate;
                                    font-family: sens-serif;
                                "
                            >
                                Frontend Development
                            </h3>
                            <p
                                style="
                                    margin: 2rem 0;
                                    text-align: justify;
                                    color: #215670;
                                "
                            >
                                Forget about static and long-loading web apps.
                                With highly scalable JavaScript frameworks such
                                as Angular, React, Vue.js at the front, we can
                                deliver web solutions that are both stylish and
                                lightning-fast.
                            </p>
                        </div>
                        <div class="row" style="padding-bottom: 50px">
                            <div class="col-md-4">
                                <div class="offer">
                                    <span
                                        class="elementor-icon-list-icon p-3"
                                        style="color: black"
                                    >
                                        <img
                                            src="../../../assets/images/web_service/html.png"
                                            width="50"
                                            class="my-3"
                                        />
                                        Html5</span
                                    >
                                    <br />
                                    <span
                                        class="elementor-icon-list-icon p-3"
                                        style="color: black"
                                    >
                                        <img
                                            src="../../../assets/images/web_service/css3.png"
                                            width="60"
                                            class="my-3"
                                        />
                                        Css3</span
                                    >
                                    <br />
                                    <span
                                        class="elementor-icon-list-icon p-3"
                                        style="margin-right: 10px; color: black"
                                    >
                                        <img
                                            src="../../../assets/images/web_service/bootstrap.png"
                                            width="40"
                                            class="my-3"
                                        />
                                        Bootstrap
                                    </span>
                                    <br />
                                </div>
                            </div>
                            <div class="col-md-4" data-aos="flip-up">
                                <div class="offer">
                                    <span
                                        class="elementor-icon-list-icon p-3"
                                        style="color: black"
                                    >
                                        <img
                                            src="../../../assets/images/web_service/js.png"
                                            width="50"
                                            class="my-3"
                                        />
                                        JavaScript</span
                                    >
                                    <br />
                                    <span
                                        class="elementor-icon-list-icon p-3"
                                        style="color: black"
                                    >
                                        <img
                                            src="../../../assets/images/web_service/jquery.png"
                                            width="50"
                                            class="my-3"
                                        />
                                        Jquery
                                    </span>
                                    <br />
                                    <span
                                        class="elementor-icon-list-icon p-3"
                                        style="color: black"
                                    >
                                        <img
                                            src="../../../assets/images/web_service/react.png"
                                            width="50"
                                            class="my-3"
                                        />
                                        React
                                    </span>
                                </div>
                            </div>
                            <div class="col-md-4" data-aos="flip-right">
                                <div class="offer">
                                    <span
                                        class="elementor-icon-list-icon p-3"
                                        style="color: black"
                                    >
                                        <img
                                            src="../../../assets/images/web_service/vuejs.png"
                                            width="50"
                                            class="my-3"
                                        />

                                        Vue js
                                    </span>
                                    <br />
                                    <span
                                        class="elementor-icon-list-icon p-3"
                                        style="color: black"
                                    >
                                        <img
                                            src="../../../assets/images/web_service/tailwindcss.png"
                                            width="50"
                                            class="my-3"
                                        />
                                        Tailwind css</span
                                    >
                                    <br />
                                    <span
                                        class="elementor-icon-list-icon p-3"
                                        style="color: black"
                                    >
                                        <img
                                            src="../../../assets/images/web_service/sass.png"
                                            width="50"
                                            class="my-3"
                                        />
                                        sass</span
                                    >
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="container row">
                        <div class="col-md-12">
                            <h3
                                class="text-capitalize"
                                style="
                                    color: chocolate;
                                    font-family: sens-serif;
                                "
                            >
                                Backend Development
                            </h3>
                            <p
                                style="
                                    margin: 2rem 0;
                                    text-align: justify;
                                    color: #215670;
                                "
                            >
                                We deliver complex, secure and well-documented
                                backend solutions with resizable computing
                                capacity that scale naturally within the
                                industry’s best cloud platforms. Whether it’s a
                                web app, custom backend system or an API, we
                                create architectures that best suit your digital
                                products.
                            </p>
                        </div>
                        <div class="row" style="padding-bottom: 50px">
                            <div class="col-md-4">
                                <div class="offer">
                                    <span
                                        class="elementor-icon-list-icon p-3"
                                        style="color: black"
                                    >
                                        <img
                                            src="../../../assets/images/web_service/laravel.png"
                                            width="50"
                                            class="my-3"
                                        />
                                        Laravel</span
                                    >
                                    <br />
                                    <span
                                        class="elementor-icon-list-icon p-3"
                                        style="color: black"
                                    >
                                        <img
                                            src="../../../assets/images/web_service/python.png"
                                            width="50"
                                            class="my-3"
                                        />
                                        Python</span
                                    >
                                    <br />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--  our teach stack  part end -->

    <!-- Technologies  uses part start -->
    <!-- <section>
        <div class="container">
            <div class="row">
                <div class="col-sm-12 mt-4 mb-4">
                    <h2 class="global-title text-center">
                        <span class="rounded">Technologies we use</span>
                    </h2>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="owl-carousel owl-theme owl-loaded pb-3">
                        <div class="owl-stage-outer">
                            <div class="owl-stage">
                                <div class="owl-item">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/technologies/css3.png"
                                            /></a>
                                        </div>
                                        <div class="col-md-4 d-none d-md-block">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/technologies/html.png"
                                            /></a>
                                        </div>
                                        <div class="col-md-4 d-none d-md-block">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/technologies/javascript.png"
                                            /></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="owl-item">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/technologies/jquery.png"
                                            /></a>
                                        </div>
                                        <div class="col-md-4 d-none d-md-block">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/technologies/laravel.png"
                                            /></a>
                                        </div>
                                        <div class="col-md-4 d-none d-md-block">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/technologies/mysql.png"
                                            /></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="owl-item">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/technologies/php_logo.png"
                                            /></a>
                                        </div>
                                        <div class="col-md-4 d-none d-md-block">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/technologies/typescript.png"
                                            /></a>
                                        </div>
                                        <div class="col-md-4 d-none d-md-block">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/technologies/vuejs.png"
                                            /></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="owl-item">
                                    <div class="row">
                                        <div class="col-md-4 d-none d-md-block">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/technologies/html.png"
                                            /></a>
                                        </div>
                                        <div class="col-md- d-none d-md-block4">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/technologies/css3.png"
                                            /></a>
                                        </div>
                                        <div class="col-md-4">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/technologies/reactjs.png"
                                            /></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="owl-item">
                                    <div class="row">
                                        <div class="col-md-4 d-none d-md-block">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/technologies/html.png"
                                            /></a>
                                        </div>
                                        <div class="col-md-4">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/technologies/javascript.png"
                                            /></a>
                                        </div>
                                        <div class="col-md-4 d-none d-md-block">
                                            <a class="thumbnail" href="#"
                                                ><img
                                                    alt=""
                                                    src="../../../assets/images/technologies/css3.png"
                                            /></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section> -->
    <!-- Technologies  uses part end -->

    <!--custom software  part start -->
    <section class="web_offer" style="font-family: sens-serif">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 mt-4 mb-4">
                    <h2
                        class="text-center global-title"
                        style="font-family: sens-serif"
                    >
                        <span class="rounded">
                            Our web application development process
                        </span>
                    </h2>
                </div>
                <div class="col-sm-12 mt-4 mb-4">
                    <p style="color: #215670; text-transform: capitalize">
                        Our approach to website application development relies
                        on a few general rules of software development. We have
                        experience in Agile, Scrum, Kanban, and Waterfall models
                        but suggest sticking to the first one as it offers the
                        best outcomes, helps to control and deliver efficiently.
                    </p>
                </div>
            </div>
        </div>
    </section>
    <!-- custom software part end -->

    <!-- start of title content row  -->
    <!-- <div class="container row">
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Requirements gathering and analysis
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                First and foremost, you express your ideas, wishes, limitations,
                functional and non-functional requirements personally, in text
                or voice. Our Business Analysts check everything, and the
                project team identifies the best possible solution. This stage
                results in detailed project plans and SRS.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Basic design, wireframing
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                Further, developers and designers start working on the basic
                wireframes – structures of your future application, so-called
                blueprints. Further, we also create mockups to show how texts,
                graphics, and other elements will fit the basic structure. This
                stage helps to get a general idea of your custom web
                application.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Architecture planning and prototyping
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                This phase focuses on UI/UX design and prototyping – the
                creation of interactive demos of your app. As well, you can get
                the MVP to test the app’s viability without spending a lot of
                time and money. This step of website application development
                delivers architecture basics, too.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Frontend and backend development
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                After designs and interfaces are approved, we hand over all
                UI/UX elements and kits to the dev team. Frontend and backend
                coding provide for the creation of client- and server-side parts
                of the app. You can check the results regularly, submit change
                requests, and discuss your ideas with our team.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Testing and QA
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                Iterative testing helps us to get rid of bugs and ensure that
                the developed software meets your requirements and other
                metrics. Our clients get the full range of manual and automated
                testing services: functional, integration, interoperability,
                scalability, security, system, usability, and other types of
                testing.
            </p>
        </div>
        <div class="col-md-6">
            <h3
                class="text-capitalize"
                style="color: chocolate; font-family: sens-serif"
            >
                Deployment
            </h3>
            <p style="margin: 2rem 0; text-align: justify; color: #215670">
                Once the final build is completed, tested, and approved, you can
                get it together with all the related elements: UI/UX,
                documentation, code, etc. Usually, you should finish the
                deployment via your environment. However, our developers and
                test engineers can help with this stage, too.
            </p>
        </div>
    </div> -->
    <!-- end of title content row  -->

    <!-- ======= nine different sections Section ======= -->
    <section id="why-us" class="why-us section-bg px-5 py-5">
        <div class="container-fluid">
            <!-- first ROW strat -->
            <div class="row">
                <div class="col-lg-4">
                    <div class="row">
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class="img-1st"
                                    src="../../../assets/img/bigdata.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <img
                                    src="../../../assets/img/border-1.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <div class="img-2nd center">
                                    <span>01</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class=""
                                    src="../../../assets/img/arrow-1.png"
                                    alt="Avatar"
                                />
                            </div>
                        </div>

                        <div class="content-box">
                            <h4 class="center">
                                <a href="" style="color: #92e3a9"
                                    >Requirements gathering and analysis
                                </a>
                            </h4>
                            <p>
                                First and foremost, you express your ideas,
                                wishes, limitations, functional and
                                non-functional requirements personally, in text
                                or voice. Our Business Analysts check
                                everything, and the project team identifies the
                                best possible solution. This stage results in
                                detailed project plans and SRS.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="row">
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class="img-1st"
                                    src="../../../assets/img/research.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <img
                                    src="../../../assets/img/border-1.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <div class="img-2nd center">
                                    <span>02</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="center">
                                <img
                                    class=""
                                    src="../../../assets/img/arrow-1.png"
                                    alt="Avatar"
                                />
                            </div>
                        </div>

                        <div class="content-box">
                            <h4 class="center">
                                <a href="" style="color: #92e3a9"
                                    >Basic design, wireframing
                                </a>
                            </h4>
                            <p>
                                Further, developers and designers start working
                                on the basic wireframes – structures of your
                                future application, so-called blueprints.
                                Further, we also create mockups to show how
                                texts, graphics, and other elements will fit the
                                basic structure. This stage helps to get a
                                general idea of your custom web application.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="row">
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class="img-1st"
                                    src="../../../assets/img/blueprint.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <img
                                    src="../../../assets/img/border-1.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <div class="img-2nd center">
                                    <span>03</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="center">
                                <img
                                    src="../../../assets/img/arrow-1.png"
                                    alt="Avatar"
                                />
                            </div>
                        </div>

                        <div class="content-box wow slideInUp animated">
                            <h4 class="center">
                                <a href="" style="color: #92e3a9">
                                    Architecture planning and prototyping
                                </a>
                            </h4>
                            <p>
                                This phase focuses on UI/UX design and
                                prototyping – the creation of interactive demos
                                of your app. As well, you can get the MVP to
                                test the app’s viability without spending a lot
                                of time and money. This step of website
                                application development delivers architecture
                                basics, too.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- first ROW End -->

            <!-- third ROW strat -->
            <div class="row">
                <div class="col-lg-4">
                    <div class="row">
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class="img-1st"
                                    src="../../../assets/img/deploy.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <img
                                    src="../../../assets/img/border-1.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <div class="img-2nd center">
                                    <span>04</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="center">
                                <img
                                    class=""
                                    src="../../../assets/img/arrow-1.png"
                                    alt="Avatar"
                                />
                            </div>
                        </div>

                        <div class="content-box">
                            <h4 class="center">
                                <a href="" style="color: #92e3a9"
                                    >Frontend and backend development
                                </a>
                            </h4>
                            <p>
                                After designs and interfaces are approved, we
                                hand over all UI/UX elements and kits to the dev
                                team. Frontend and backend coding provide for
                                the creation of client- and server-side parts of
                                the app. You can check the results regularly,
                                submit change requests, and discuss your ideas
                                with our team.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="row">
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class="img-1st"
                                    src="../../../assets/img/deploy.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <img
                                    src="../../../assets/img/border-1.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <div class="img-2nd center">
                                    <span>05</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="center">
                                <img
                                    class=""
                                    src="../../../assets/img/arrow-1.png"
                                    alt="Avatar"
                                />
                            </div>
                        </div>

                        <div class="content-box">
                            <h4 class="center">
                                <a href="" style="color: #92e3a9"
                                    >Testing and QA
                                </a>
                            </h4>
                            <p>
                                Iterative testing helps us to get rid of bugs
                                and ensure that the developed software meets
                                your requirements and other metrics. Our clients
                                get the full range of manual and automated
                                testing services: functional, integration,
                                interoperability, scalability, security, system,
                                usability, and other types of testing.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="row">
                        <div class="col-md-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class="img-1st"
                                    src="../../../assets/img/blueprint.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <img
                                    src="../../../assets/img/border-1.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <div class="img-2nd center">
                                    <span>06</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="center">
                                <img
                                    src="../../../assets/img/arrow-1.png"
                                    alt="Avatar"
                                />
                            </div>
                        </div>

                        <div class="content-box wow slideInUp animated">
                            <h4 class="center">
                                <a href="" style="color: #92e3a9">
                                    Deployment
                                </a>
                            </h4>
                            <p>
                                Once the final build is completed, tested, and
                                approved, you can get it together with all the
                                related elements: UI/UX, documentation, code,
                                etc. Usually, you should finish the deployment
                                via your environment. However, our developers
                                and test engineers can help with this stage,
                                too.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="row">
                        <div class="col-lg-6 mb-5 mb-md-0">
                            <div class="center">
                                <img
                                    class="img-1st"
                                    src="../../../assets/img/deploy.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <img
                                    src="../../../assets/img/border-1.png"
                                    alt="Avatar"
                                />
                            </div>
                            <div class="center">
                                <div class="img-2nd center">
                                    <span>07</span>
                                </div>
                            </div>
                            <div class="content-box center">
                                <h4 class="center">
                                    <a href="" style="color: #92e3a9">
                                        Maintenance and upgrades
                                    </a>
                                </h4>
                                <p>
                                    After deployment, your custom web
                                    application is live. But we provide full
                                    tech support and maintenance. At any moment,
                                    you can return and ask to fix some things,
                                    add or remove features, change the design,
                                    optimize legacy modules, migrate data, etc.
                                    Moreover, we handle upgrades of third-party
                                    applications.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- third ROW End -->
        </div>
    </section>
    <!-- End nine different sections Section -->

    <div class="container">
        <div class="row">
            <div
                class="
                    col-md-12
                    d-flex
                    justify-content-center
                    align-items-center
                "
            >
                <p class="get_quote_button">
                    <router-link :to="{ name: 'Contact' }" class=""
                        >get a free quote now</router-link
                    >
                </p>
            </div>
        </div>
    </div>
</template>

<script>
import SliderFont from "../../../assets/js/slider_font";
import OwlCarousel from "../../../assets/js/owl.carousel.min.js";
export default {
    mounted() {
        OwlCarousel();
        SliderFont();
        document.title = "WEB APPLICATION | Excel IT AI";
        window.scrollTo({ top: 0, behavior: "smooth" });
    },
};
</script>

<style scoped>
@import "../../../assets/css/bootstrap5.min.css";
ul {
    margin: 0;
    padding: 0;
    list-style: none;
}

a {
    text-decoration: none;
}

p {
    font-size: 18px;
    line-height: 1.2;
}

h1,
h2,
h3,
h4,
h5,
h6 {
    font-family: "Courier New", Courier, monospace;
    font-weight: 700;
    line-height: 1.2;
}

h1 {
    font-size: 3.375rem;
}

h2 {
    font-size: 2rem;
}

.carousel-item img {
    height: 400px;
    width: 100%;
    object-fit: cover;
}

.thumbnail {
    width: 100%;
    height: 100%;
}
.thumbnail img {
    width: 150px !important;
    height: 150px !important;
    object-fit: fill;
}

.elementor-icon-list-icon {
    color: black !important;
}

/* custosoftware process  */

.img-1st {
    border-radius: 50%;
    height: 75px;
    width: 75px;
    border-style: dotted;
    border-width: 2px;
    border-color: #92e3a9;
    text-align: center;
    padding: 1px;
    transition: 0.3s;
}
.img-2nd {
    border-radius: 50%;
    height: 50px;
    width: 50px;
    /* border-style: solid; */
    /* border-width: 1px; */
    /* border-color: #fb6064; */
    text-align: center;
    padding-top: 4px;
}
.img-2nd span {
    position: relative;
    display: inline-block;
    width: 40px;
    height: 40px;
    line-height: 40px;
    font-size: 15px;
    font-family: "Muli", Sans-serif;
    font-weight: 700;
    color: #fff;
    border-radius: 50%;
    background-color: red;
    border-color: floralwhite;
    border: 2px;
}
.center {
    display: block;
    margin-left: auto;
    margin-right: auto;
    width: 50%;
    text-align: center;
    /* border: 1px solid; */
    /* border: 1px solid red; */
}

.img-1st:hover {
    background-color: #92e3a9;
    cursor: pointer;
}

.content-box {
    height: auto;
    width: 300px;
    position: relative;
    display: block;
    background: linear-gradient(to bottom, rgb(65, 95, 205), rgb(68, 144, 188));
    padding: 47px 30px 43px 30px;
    border-radius: 30px;
    margin-left: 10px;
    box-shadow: 0 10px 30px rgb(0 0 0 / 10%);
    margin-top: 50px;
    margin-bottom: 50px;
    border: 10px solid #92e3a9;
    /* border: 10px solid #215670; */
}
.content-box h4 a {
    font-size: 1.3rem !important;
}

.content-box p {
    color: #fff;
}
</style>
