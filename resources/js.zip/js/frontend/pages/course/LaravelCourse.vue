<template>
    <div class="course-header mt-5">
        <h2 class="mt-5 pt-5">Laravel Course</h2>
        <div class="d-flex justify-content-center">
            <img src="../../../../assets/images/course_bg/laravel.png" />
        </div>
    </div>
    <section
        class="accordion-section clearfix mt-3"
        aria-label="Question Accordions"
    >
        <div class="container">
            <!-- <h3 style="text-align: center">Frequently Asked Questions</h3> -->
            <br />
            <br />
            <!--  -->
            <div class="container">
                <div class="row">
                    <div class="col-12 col-md-6">
                        <div class="list-group">
                            <Accordian header="HTML Review 1">
                                <ul>
                                    <li>Introduction and Installation</li>
                                </ul>
                            </Accordian>
                            <Accordian header="HTML Review 1">
                                <ul>
                                    <li>Introduction and Installation</li>
                                </ul>
                            </Accordian>
                            <Accordian header=" HTML Review 2">
                                <ul>
                                    <li>HTML Tags</li>
                                    <li>Attributes</li>
                                    <li>Elements</li>
                                    <li>Comments</li>
                                    <li>Head</li>
                                    <li>Body</li>
                                    <li>Section</li>
                                </ul>
                            </Accordian>
                            <Accordian header=" HTML Review 2">
                                <ul>
                                    <li>HTML Tags</li>
                                    <li>Attributes</li>
                                    <li>Elements</li>
                                    <li>Comments</li>
                                    <li>Head</li>
                                    <li>Body</li>
                                    <li>Section</li>
                                </ul>
                            </Accordian>
                            <Accordian header=" HTML Review 3">
                                <ul>
                                    <li>Div</li>
                                    <li>Header</li>
                                    <li>Footer</li>
                                    <li>Page Title</li>
                                    <li>Headings</li>
                                    <li>Paragraphs</li>
                                </ul>
                            </Accordian>
                            <Accordian header="HTML Review 4 ">
                                <ul>
                                    <li>Images,</li>
                                    <li>Video and Audio tags</li>
                                </ul>
                            </Accordian>
                            <Accordian header="HTML Review 5">
                                <ul>
                                    <li>Hyperlinks,</li>
                                    <li>Lists</li>
                                    <li>Tables & Form Making</li>
                                </ul>
                            </Accordian>
                            <Accordian header=" Bootstrap Recap - 6">
                                <ul>
                                    <li>Bootstrap Basic Template</li>
                                </ul>
                            </Accordian>
                            <Accordian header="JavaScript-C1">
                                <ul>
                                    <li>JS Operators</li>
                                </ul>
                            </Accordian>
                            <Accordian header="JavaScript-C2">
                                <ul>
                                    <li>
                                        Simple Function, Parameter, Argument
                                    </li>
                                </ul>
                            </Accordian>
                            <Accordian header="JavaScript-C3">
                                <ul>
                                    <li>
                                        If Else Statement, Handling Multiple
                                        Condition
                                    </li>
                                </ul>
                            </Accordian>

                            <Accordian header="JavaScript-C4">
                                <ul>
                                    <li>Form Validation</li>
                                    <li>Advanced Form Validation</li>
                                </ul>
                            </Accordian>
                            <Accordian header="Introduction to Laravel 8:">
                                <ul>
                                    <li>History of PHP framework</li>
                                    <li>Introduce to MVC</li>
                                    <li>
                                        Why Laravel. Laravel 8 installation.
                                    </li>
                                </ul>
                            </Accordian>
                            <Accordian header="Laravel Architecture Concepts">
                                <ul>
                                    <li>
                                        Project folder structure.Route
                                        Introduction & Route Naming. Request
                                        Lifecycle.
                                    </li>
                                </ul>
                            </Accordian>
                            <Accordian header="Laravel Architecture Concepts">
                                <ul>
                                    <li>
                                        Project folder structure.Route
                                        Introduction & Route Naming. Request
                                        Lifecycle.
                                    </li>
                                </ul>
                            </Accordian>
                            <Accordian header="Laravel Architecture Concepts">
                                <ul>
                                    <li>Request Lifecycle</li>
                                    <li>Service Containers</li>
                                    <li>Service Providers</li>
                                    <li>Facades</li>
                                    <li>Contracts</li>
                                </ul>
                            </Accordian>
                            <Accordian header="Laravel Fundamental Routing">
                                <ul>
                                    <li>Basic Routing</li>
                                    <li>Group Routings</li>
                                    <li>
                                        Resource view route.Data passing process
                                        without controller.
                                    </li>
                                </ul>
                            </Accordian>
                            <Accordian header="Template Mastering ">
                                <ul>
                                    <li>
                                        Adding Bootstrap plus login and
                                        Registration
                                    </li>
                                    <li>Add template to Laravel project</li>
                                </ul>
                            </Accordian>
                            <Accordian header="Eloquent ORM">
                                <ul>
                                    <li>Relationships</li>
                                    <li>Collections</li>
                                </ul>
                            </Accordian>
                            <Accordian header="Eloquent ORM">
                                <ul>
                                    <li>Mutators / Casts</li>
                                    <li>API Resources</li>
                                </ul>
                            </Accordian>
                            <Accordian header="Git and Github">
                                <ul>
                                    <li>Git and Github Basic</li>
                                </ul>
                            </Accordian>
                            <Accordian header="API">
                                <ul>
                                    <li>
                                        Concept of API, why and scope of
                                        implementation
                                    </li>
                                    <li>Tools ~ Postman Tool</li>
                                    <li>Basic project</li>
                                </ul>
                            </Accordian>
                            <Accordian header="Package and Validation">
                                <ul>
                                    <li>
                                        Modifying our create form with the form
                                        package
                                    </li>
                                </ul>
                            </Accordian>
                            <Accordian header="Practice Live Project">
                                <ul>
                                    <li>
                                        Modifying our create form with the form
                                        package
                                    </li>
                                </ul>
                            </Accordian>
                        </div>
                    </div>
                    <div class="col-12 col-md-6">
                        <div class="list-group">
                            <Accordian header="CSS Rehash - 1">
                                <ul>
                                    <li>
                                        Types of Style Sheets, CSS Selectors,
                                        Properties, Values, Backgrounds, Colors
                                    </li>
                                </ul>
                            </Accordian>
                            <Accordian header="CSS Rehash - 2">
                                <ul>
                                    <li>Text Styling & Formatting,</li>
                                    <li>Borders</li>
                                    <li>Margins</li>
                                    <li>Padding</li>
                                    <li>Outlines</li>
                                </ul>
                            </Accordian>
                            <Accordian header="CSS Rehash - 3">
                                <ul>
                                    <li>Pixels, Percentages, Points</li>
                                    <li>Em</li>
                                    <li>Block & Inline Elements</li>
                                    <li>Float & Clear</li>
                                </ul>
                            </Accordian>
                            <Accordian header="CSS Rehash - 4">
                                <strong>
                                    <a
                                        style="color: #fff"
                                        href="http://growwithfunnels.com"
                                    >
                                        Grow with funnels</a
                                    >
                                </strong>
                            </Accordian>
                            <Accordian header="CSS Rehash - 5">
                                <ul>
                                    <li>ID & Class Selectors</li>
                                    <li>Layers</li>
                                </ul>
                            </Accordian>
                            <Accordian header="Bootstrap Recap - 1">
                                <ul>
                                    <li>What is Bootstrap</li>
                                    <li>How to use it</li>
                                    <li>Bootstrap Grid system</li>
                                    <li>Typography</li>
                                </ul>
                            </Accordian>
                            <Accordian header="Bootstrap Recap - 2">
                                <ul>
                                    <li>
                                        Tables,<br />Breadcrumbs,<br />Pagination,<br />Labels,
                                    </li>
                                </ul>
                            </Accordian>
                            <Accordian header="Bootstrap Recap - 3">
                                <ul>
                                    <li>Badges, Alerts</li>
                                    <li>Buttons.Forms</li>
                                    <li>Bootstrap Navs, Navbar</li>
                                </ul>
                            </Accordian>
                            <Accordian header="Bootstrap Recap - 4">
                                <ul>
                                    <li>Bootstrap Display</li>
                                    <li>Flex, Float</li>
                                    <li>Shadow, sizing</li>
                                </ul>
                            </Accordian>
                            <Accordian header="Bootstrap Recap - 5">
                                <ul>
                                    <li>spacing</li>
                                    <li>vertical Align</li>
                                    <li>
                                        Starting to make a Personal Portfolio
                                        webpage
                                    </li>
                                </ul>
                            </Accordian>
                            <Accordian header="JavaScript-C5">
                                <ul>
                                    <li>JSON Format</li>
                                    <li>Auto Select</li>
                                </ul>
                            </Accordian>
                            <Accordian header="JavaScript-C6">
                                <ul>
                                    <li>Confirm Function</li>
                                    <li>
                                        Understanding server side technology
                                    </li>
                                </ul>
                            </Accordian>
                            <Accordian header="PHP">
                                <ul>
                                    <li>PHP development environment.</li>
                                    <li>PHP Basic Syntax</li>
                                    <li>PHP Variable & Data Type</li>
                                    <li>PHP Operator,PHP Statement.</li>
                                    <li>Built in Array and Function.</li>
                                    <li>PHP super global variable.</li>
                                </ul>
                            </Accordian>
                            <Accordian header="OOP">
                                <ul>
                                    <li>Understanding the concept of OOP</li>
                                    <li>JS Operators</li>
                                </ul>
                            </Accordian>
                            <Accordian header="Database">
                                <ul>
                                    <li>
                                        Introduce to Database and MySQL Database
                                        Server.
                                    </li>
                                </ul>
                            </Accordian>
                            <Accordian header="Laravel Fundamental">
                                <ul>
                                    <li>Middleware</li>
                                    <li>CSRF Protection</li>
                                    <li>Controllers</li>
                                    <li>Requests Responses</li>
                                    <li>Views</li>
                                </ul>
                            </Accordian>
                            <Accordian
                                header="Laravel Fundamental Digging Deeper"
                            >
                                <ul>
                                    <li>Artisan Console</li>
                                    <li>Broadcasting</li>
                                    <li>Cache</li>
                                    <li>Collections</li>
                                    <li>Contracts</li>
                                    <li>Events</li>
                                </ul>
                            </Accordian>
                            <Accordian header="Laravel Advance Digging Deeper">
                                <ul>
                                    <li>File Storage</li>
                                    <li>Helpers</li>
                                    <li>HTTP Client</li>
                                    <li>Notificationsl</li>
                                    <li>Package Developments</li>
                                    <li>Queues</li>
                                    <li>Task Scheduling</li>
                                </ul>
                            </Accordian>
                            <Accordian header="Authentication">
                                <ul>
                                    <li>
                                        Authentication Starter Kits (Breeze,
                                        Jetstream
                                    </li>
                                    <li>User registration, Login</li>
                                    <li>
                                        Introduce to Migration, Schema, and
                                        Blueprint.
                                    </li>
                                    <li>Create migration file</li>
                                    <li>
                                        Prepare migration file for creating
                                        table
                                    </li>
                                </ul>
                            </Accordian>
                            <Accordian header="Laravel Front End">
                                <ul>
                                    <li>
                                        i. Adding Bootstrap plus login and
                                        Registration
                                    </li>
                                    <li>ii. Add template to Laravel project</li>
                                </ul>
                            </Accordian>
                            <Accordian header="Laravel Package ">
                                <ul>
                                    <li>Installing packages and testing</li>
                                </ul>
                            </Accordian>
                            <Accordian header=" Laravel Architecture Concepts">
                                <ul>
                                    <li>Request Lifecycle</li>
                                    <li>Service Containers</li>
                                    <li>Service Providers</li>
                                    <li>Facades</li>
                                    <li>Contracts</li>
                                </ul>
                            </Accordian>
                            <Accordian header="Laravel Fundamental Routing">
                                <ul>
                                    <li>Basic Routing</li>
                                    <li>Group Routings</li>
                                    <li>
                                        Resource view route.Data passing process
                                        without controller.
                                    </li>
                                </ul>
                            </Accordian>
                            <Accordian header="Laravel Fundamental Routing">
                                <ul>
                                    <li>Basic Routing</li>
                                    <li>Group Routings</li>
                                    <li>
                                        Resource view route.Data passing process
                                        without controller.
                                    </li>
                                </ul>
                            </Accordian>
                        </div>
                        <br />
                    </div>
                </div>
            </div>
        </div>
    </section>
</template>

<script>
import Accordian from "./components/Accordian.vue";
export default {
    components: { Accordian },
    mounted() {
        document.title = "LARAVEL COURSE | Excel IT AI";
        window.scrollTo({ top: 0, behavior: "smooth" });
    },
};
</script>

<style scoped>
.course-header {
    background: url("../../../../assets/images/course_bg/web_development_bg.png");
    height: 700px;
    position: relative;
    background-repeat: no-repeat;
    background-attachment: fixed;
    background-size: cover;
    background-position: center;
    width: 100%;
    padding-top: 5rem;
}
.course-header h2 {
    width: 100% !important;
    /* height: 80px; */
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 5rem !important;
    color: #fff;
    position: relative;
    z-index: 1000;
    /* background: #215670 !important;
    /* border-radius: 25px / 17px; */
    /* border-radius: 50px / 50px !important; */
}
@media screen and (max-width: 700px) {
    .course-header h2 {
        margin-left: 4rem;
    }
}
.course-header::before {
    position: absolute;
    content: "";
    top: 0;
    right: 0;
    left: 0;
    bottom: 0;
    background: linear-gradient(
        to right,
        rgba(0, 0, 0, 0.4),
        rgba(21, 37, 53, 0.3)
    );
}

.course-header img {
    width: 200px;
    height: 200px;
    z-index: 10000;
    object-fit: contain;
    /* background: #fff; */
    /* box-shadow: 0 4px 6px -1px #3f92d6, 0 2px 4px -1px #3f92d6;
    border-radius: 50%; */
}
</style>
