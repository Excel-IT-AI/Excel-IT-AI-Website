<template>
    <div class="course-header mt-5">
        <h2 class="mt-5 pt-5">Digital Marketing Course</h2>
    </div>
    <section
        class="accordion-section clearfix mt-3"
        aria-label="Question Accordions"
    >
        <div class="container">
            <div class="container">
                <div class="row"></div>
                <div class="row">
                    <div class="col-12 col-md-6">
                        <div class="list-group">
                            <Accordian
                                header=" History, Purpose & Future of Digital Marketing"
                            >
                                <ul>
                                    <li>Digital Marketing Activity</li>
                                    <li>
                                        Elaborate the history of Digital
                                        Marketing
                                    </li>
                                    <li>Elaborate the purpose of DGM</li>
                                    <li>Elaborate the future of DGM</li>
                                </ul>
                            </Accordian>
                            <Accordian
                                header="Introduction to Digital Marketing"
                            >
                                <ul>
                                    <li>SMM (Social Media Marketing)</li>
                                    <li>SEM (Search Engine Marketing)</li>
                                    <li>SEO (Search Engine Optimization)</li>
                                </ul>
                            </Accordian>
                            <Accordian header="Social Media Marketing">
                                <ul>
                                    <li>What is Social Media Marketing?</li>
                                    <li>Describe different types of SMM</li>
                                </ul>
                            </Accordian>
                            <Accordian header="Search Engine Marketing ">
                                <ul>
                                    <li>What is Search Engine Marketing</li>
                                    <li>Describe different types of SEM</li>
                                </ul>
                            </Accordian>

                            <Accordian header="Graphics Design & Video making">
                                <ul>
                                    <li>Step of Graphics design idea</li>
                                    <li>Simple video Making (PPT & Filmora)</li>
                                </ul>
                            </Accordian>
                            <Accordian header="Online Market (Freelancing)">
                                <ul>
                                    <li>Fiverr</li>
                                    <li>Upwork</li>
                                </ul>
                            </Accordian>
                            <Accordian header="Google Analytics Overview">
                                <ul>
                                    <li>what is Web Analytics</li>
                                    <li>Integrating with Website</li>
                                    <li>Measurement Metrics</li>
                                    <li>How to create google analytics code</li>
                                    <li>Analytics Reporting</li>
                                    <li>Sorting, Filter and Time Chart</li>
                                    <li>Audience Segmentation</li>
                                    <li>Traffic and Behaviour Reports</li>
                                    <li>Remarketing Audiences</li>
                                    <li>Goals and Conversion Reports</li>
                                    <li>Google Webmaster Tool</li>
                                    <li>Setting up Tool for SEO</li>
                                    <li>Adding and Managing Assets</li>
                                    <li>Integrating Webmaster Tool</li>
                                    <li>Google Indexing</li>
                                    <li>Managing Crawl Errors</li>
                                </ul>
                            </Accordian>
                            <Accordian header="Linkedin Marketing">
                                <ul>
                                    <li>LinkedIN -The hub of B2B Networking</li>
                                    <li>Creating LinkedIn Account</li>
                                    <li>
                                        Updating Contact Information and Links
                                    </li>
                                    <li>Designing Profile and Summary</li>
                                    <li>Managing Connections</li>
                                    <li>Advance Searching</li>
                                    <li>Who Viewed Your Profile</li>
                                    <li>
                                        Endorsements -Publishing and Receiving
                                    </li>
                                    <li>Creating LinkedIn Company Page</li>
                                    <li>Updating Products and Services</li>
                                </ul>
                            </Accordian>

                            <Accordian
                                header=" Youtube marketing Practical Sessions"
                            >
                                <ul>
                                    <li>Who Viewed Your Profile</li>
                                    <li>
                                        Endorsements -Publishing and Receiving
                                    </li>
                                    <li>Creating LinkedIn Company Page</li>
                                    <li>Updating Products and Services</li>
                                </ul>
                            </Accordian>

                            <Accordian
                                header=" Practical Sessions for Good Profile Creation"
                            >
                                <ul>
                                    <li>Who Viewed Your Profile</li>
                                    <li>
                                        Endorsements -Publishing and Receiving
                                    </li>
                                </ul>
                            </Accordian>
                            <Accordian header="Fiverr GIG">
                                <ul>
                                    <li>Title</li>
                                    <li>Portfolio</li>
                                    <li>Description & Packages</li>
                                    <li>Tags</li>
                                    <li>buyer</li>
                                </ul>
                            </Accordian>
                            <Accordian
                                header="Fiverr GIG Review and Buyer Request"
                            >
                                <ul>
                                    <li>
                                        How to submit offers to Buyer Requests
                                    </li>
                                    <li>What to write in Buyer Request</li>
                                    <li>Replying to buyer messages.</li>
                                    <li>Custom offer.</li>
                                    <li>Buyer Review.</li>
                                </ul>
                            </Accordian>
                            <Accordian
                                header=" Practical Sessions for Buyer Request"
                            >
                                <ul>
                                    <li>Description & Packages</li>
                                    <li>Tags</li>
                                    <li>buyer</li>
                                </ul>
                            </Accordian>
                            <Accordian
                                header=" Practical Sessions for Buyer Request"
                            >
                                <ul>
                                    <li>Description & Packages</li>
                                    <li>Tags</li>
                                    <li>buyer</li>
                                </ul>
                            </Accordian>
                        </div>
                    </div>

                    <div class="col-12 col-md-6">
                        <div class="list-group">
                            <Accordian header="SMM Overview">
                                <ul>
                                    <li>What is SMM?</li>
                                    <li>
                                        Social Media Marketing descriptions.
                                    </li>
                                </ul>
                            </Accordian>

                            <Accordian header="Facebook Marketing">
                                <ul>
                                    <li>What is Facebook Marketing</li>
                                    <li>
                                        How to create Facebook Profiles and
                                        Pages
                                    </li>
                                    <li>How to Create Shop in facebook</li>
                                    <li>
                                        How to setup facebook Business (Shopify
                                        to custom tab)
                                    </li>
                                    <li>
                                        Creating Different types of Facebook
                                        Pages
                                    </li>
                                    <li>
                                        Edit facebook Page Info and Settings
                                    </li>
                                    <li>Facebook Page Custom URL</li>
                                    <li>Invite friends for Page Likes</li>
                                    <li>How to create Facebook Events</li>
                                    <li>
                                        Facebook Query Management (Reply and
                                        Message)
                                    </li>
                                    <li>Facebook Insights Reports</li>
                                    <li>Ban User on Facebook Page</li>
                                    <li>
                                        How to create Lead generation campaign
                                        on FB
                                    </li>
                                    <li>
                                        How to generate monthly report on FB
                                    </li>
                                </ul>
                            </Accordian>
                            <Accordian header="Facebook Add Campaign">
                                <ul>
                                    <li>Facebook Organic v/s Paid</li>
                                    <li>Defining Facebook Ad Objective</li>
                                    <li>
                                        Performance Matrix for Facebook campaign
                                    </li>
                                    <li>Facebook Ad Components</li>
                                    <li>
                                        Designing Creative Image for Facebook
                                        post
                                    </li>
                                    <li>Facebook Ad Structure</li>
                                    <li>Setting Up Facebook Ad Account</li>
                                    <li>
                                        Create Ad -Targeting for facebook post
                                    </li>
                                    <li>
                                        Create Ad -Budgeting for facebook post
                                    </li>
                                    <li>
                                        Create Ad -Creative for facebook post
                                    </li>
                                    <li>How to create Content and CTA</li>
                                    <li>Boosting Page Posts</li>
                                    <li>Company Page Promotion</li>
                                    <li>Video Promotion on facebook</li>
                                    <li>Similar Ads and Audiences</li>
                                    <li>Tracking Pixels Code</li>
                                    <li>Remarketing -Website Visitors</li>
                                    <li>Custom Audiences -Look Alike</li>
                                    <li>Custom Audience -Saved Group</li>
                                    <li>Managing and Editing Ads</li>
                                    <li>Ad Reports and Ad Insights</li>
                                    <li>Billing and Account</li>
                                </ul>
                            </Accordian>
                            <Accordian header="Facebook Advanced Strategies">
                                <ul>
                                    <li>Facebook Business Manager</li>
                                    <li>People, Pages and Roles</li>
                                    <li>Ad Accounts Configurations</li>
                                    <li>Ad Agencies and Assigning</li>
                                    <li>Shared Login for FB Business A/c</li>
                                    <li>Power Editor -Most Advance</li>
                                    <li>Email Targeting on Facebook</li>
                                    <li>Facebook Offers</li>
                                    <li>CTA(Call to action) on Page</li>
                                    <li>Facebook Posts for Location</li>
                                    <li>
                                        How to Save Time with Third Party Tools
                                    </li>
                                    <li>Case Studies</li>
                                    <li>Practical Examples</li>
                                </ul>
                            </Accordian>
                            <Accordian header=" SEM Overview ">
                                <ul>
                                    <li>What is SEM?</li>
                                    <li>
                                        Social Engine Marketing descriptions.
                                    </li>
                                </ul>
                            </Accordian>
                            <Accordian header="Google adwords for Basics">
                                <ul>
                                    <li>Basic Understanding Adwords</li>
                                    <li>Google Ad Types</li>
                                    <li>
                                        Pricing Models on different ad on Google
                                    </li>
                                    <li>PPC(pay per click) Cost Formula</li>
                                    <li>What is Ad Page Rank</li>
                                    <li>Billing and Payments</li>
                                    <li>Adwords User Interface</li>
                                    <li>Keyword Planning</li>
                                </ul>
                            </Accordian>
                            <Accordian
                                header="Google adwords basics Practical sessions"
                            >
                                <ul>
                                    <li>What is Ad Page Rank</li>
                                    <li>Billing and Payments</li>
                                    <li>Adwords User Interface</li>
                                    <li>Keyword Planning</li>
                                </ul>
                            </Accordian>
                            <Accordian header=" Google adwords">
                                <ul>
                                    <li>Creating Ad Campaigns</li>
                                    <li>
                                        Bidding Strategy for CPC (Cost Per
                                        Click)
                                    </li>
                                    <li>Practical Examples</li>
                                </ul>
                            </Accordian>
                            <Accordian header="Re-Marketing strategies ">
                                <ul>
                                    <li>Re-Marketing Flow</li>
                                    <li>Email Re-Marketing Strategy</li>
                                    <li>Segmentation Re-Marketing Strategy</li>
                                    <li>Facebook ReMarketing</li>
                                    <li>Google Adwords ReMarketing</li>
                                    <li>Marketing Machine Bucket Filling</li>
                                    <li>Dynamic Re-Marketing for eCommerc</li>
                                    <li>Pixelingand Tracking Cycle</li>
                                    <li>Video ReMarketing</li>
                                    <li>Custom Audience ReMarketing</li>
                                    <li>Engagement Re-Marketing</li>
                                </ul>
                            </Accordian>
                            <Accordian header="Fiverr">
                                <ul>
                                    <li>Introduction to Fiverr marketplace</li>
                                    <li>Create Professional Account</li>
                                </ul>
                            </Accordian>
                            <Accordian header="Profile & GIG">
                                <ul>
                                    <li>Introduction</li>
                                    <li>Motivation + Funt</li>
                                    <li>Rules and Regulation</li>
                                </ul>
                            </Accordian>
                            <Accordian
                                header="Practical Session to Create profile and GIG"
                            >
                                <ul>
                                    <li>Introduction</li>
                                    <li>Motivation + Funt</li>
                                    <li>Rules and Regulation</li>
                                </ul>
                            </Accordian>

                            <Accordian header="A+ Fiverr Profile">
                                <ul>
                                    <li>
                                        Title, Overview, Skills & other part
                                    </li>
                                    <li>Portfolio</li>
                                    <li>Payment Method</li>
                                </ul>
                            </Accordian>
                        </div>
                        <br />
                    </div>
                </div>
            </div>
        </div>
    </section>
</template>
<script>
import Accordian from "./components/Accordian.vue";
export default {
    components: { Accordian },
    mounted() {
        document.title = "DIGITAL MARKETING COURSE | Excel IT AI";
        window.scrollTo({ top: 0, behavior: "smooth" });
    },
};
</script>

<style scoped>
.course-header {
    background: url("../../../../assets/images/course_bg/digital_marketing_bg.jpg");
    height: 700px;
    position: relative;
    background-repeat: no-repeat;
    /* background-attachment: fixed; */
    background-size: cover;
    background-position: center;
    width: 100%;
    padding-top: 5rem;
}
.course-header h2 {
    width: 100% !important;
    /* height: 80px; */
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 5rem !important;
    color: #fff;
    position: relative;
    z-index: 1000;
    /* background: #215670 !important;
    /* border-radius: 25px / 17px; */
    /* border-radius: 50px / 50px !important; */
}
@media screen and (max-width: 700px) {
    .course-header h2 {
        padding-left: 3rem !important;
        margin-top: 3rem !important;
        font-size: 4rem !important;
    }
}
.course-header::before {
    position: absolute;
    content: "";
    top: 0;
    right: 0;
    left: 0;
    bottom: 0;
    background: linear-gradient(
        to right,
        rgba(0, 0, 0, 0.4),
        rgba(21, 37, 53, 0.9)
    );
    background: linear-gradient(
        to bottom,
        rgba(0, 0, 0, 0.7),
        rgba(247, 147, 49, 0.7)
    );
}

.course-header img {
    width: 200px;
    height: 200px;
    z-index: 10000;
    object-fit: contain;
    /* background: #fff; */
    /* box-shadow: 0 4px 6px -1px #3f92d6, 0 2px 4px -1px #3f92d6;
    border-radius: 50%; */
}
</style>
