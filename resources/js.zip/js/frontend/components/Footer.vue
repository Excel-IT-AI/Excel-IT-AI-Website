<template>
    <!-- footer part start -->
    <footer class="main-footer">
        <div class="footer-top">
            <div class="container" style="color: white">
                <div class="widget-section">
                    <div class="row clearfix">
                        <div class="col-lg-4 col-md-6 col-sm-12 footer-column">
                            <div
                                id="naxly_contact_us-1"
                                class="footer-widget widget_naxly_contact_us"
                            >
                                <!--Footer Column-->
                                <div class="contact-widget">
                                    <div class="widget-title">
                                        <h3 class="text-white my-5 my-md-0">
                                            Office Location
                                        </h3>
                                        <div
                                            class="decor"
                                            style="
                                                background-image: url(https://excelitai.com/wp-content/themes/naxly/assets/images/icons/decor-3.png);
                                            "
                                        ></div>
                                    </div>
                                    <div class="widget-content">
                                        <p>
                                            17, Alhaz Samsuddin Mansion (9th
                                            Floor), Moghbazar, New Easkaton,
                                            Ramna, Dhaka-1217
                                        </p>
                                        <div>
                                            <h5 class="text-white">
                                                Quick Contact
                                            </h5>
                                            <ul class="clearfix">
                                                <li>
                                                    <span
                                                        ><i
                                                            class="fa fa-phone"
                                                        ></i
                                                    ></span>
                                                    <a
                                                        href="tel:http://+88%2001611%20815656"
                                                    >
                                                        +88 01611 815656</a
                                                    >
                                                </li>
                                                <li>
                                                    <span
                                                        ><i
                                                            class="
                                                                fa fa-envelope
                                                            "
                                                        >
                                                        </i
                                                    ></span>
                                                    <a
                                                        href="mailto:http://info@excelitai.com"
                                                    >
                                                        info@excelitai.com</a
                                                    >
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="social-icons">
                                        <ul>
                                            <li id="facebook">
                                                <a
                                                    href="https://www.facebook.com/Excelitai/"
                                                    ><span
                                                        ><i
                                                            class="
                                                                fab
                                                                fa-facebook
                                                            "
                                                        ></i></span
                                                ></a>
                                            </li>
                                            <li id="twitter">
                                                <a
                                                    href="https://twitter.com/excelitai_"
                                                    ><span
                                                        ><i
                                                            class="
                                                                fab
                                                                fa-twitter
                                                            "
                                                        ></i></span
                                                ></a>
                                            </li>
                                            <li id="linkedin">
                                                <a
                                                    href="https://bd.linkedin.com/company/excelitai"
                                                    ><span
                                                        ><i
                                                            class="
                                                                fab
                                                                fa-linkedin
                                                            "
                                                        ></i></span
                                                ></a>
                                            </li>
                                            <li id="instagram">
                                                <a
                                                    href="https://www.instagram.com/excelitai/"
                                                    ><span
                                                        ><i
                                                            class="
                                                                fab
                                                                fa-instagram
                                                            "
                                                        ></i></span
                                                ></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-12 footer-column">
                            <div
                                id="naxly_footer_services-4"
                                class="
                                    footer-widget
                                    widget_naxly_footer_services
                                "
                            >
                                <!--Start Single sidebar-->
                                <div class="links-widget">
                                    <div class="widget-title">
                                        <h3 class="text-white">Useful Links</h3>
                                        <div
                                            class="decor"
                                            style="
                                                background-image: url(https://excelitai.com/wp-content/themes/naxly/assets/images/icons/decor-3.png);
                                            "
                                        ></div>
                                    </div>
                                    <div class="widget-content">
                                        <ul class="clearfix">
                                            <!-- Title -->
                                            <li>
                                                <router-link
                                                    :to="{ name: 'Fintech' }"
                                                    >Fintech</router-link
                                                >
                                            </li>
                                            <li>
                                                <router-link
                                                    :to="{ name: 'Health' }"
                                                    >Healthcare &amp;
                                                    Medicine</router-link
                                                >
                                            </li>
                                            <li>
                                                <router-link
                                                    :to="{ name: 'Ecommerce' }"
                                                    >Financials &amp;
                                                    Banking</router-link
                                                >
                                            </li>
                                            <li>
                                                <router-link
                                                    :to="{ name: 'Education' }"
                                                    >Education</router-link
                                                >
                                            </li>
                                            <li>
                                                <router-link
                                                    :to="{
                                                        name: 'RealEstate',
                                                    }"
                                                    >Real Estate</router-link
                                                >
                                            </li>
                                            <li>
                                                <router-link
                                                    :to="{
                                                        name: 'RetailSoftware',
                                                    }"
                                                    >Retail
                                                    Software</router-link
                                                >
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-12 footer-column">
                            <div
                                id="naxly_about_company_two-4"
                                class="
                                    footer-widget
                                    widget_naxly_about_company_two
                                "
                            >
                                <!--Footer Column-->
                                <div class="about-widget">
                                    <div class="widget-title">
                                        <h3 class="text-white">
                                            About Company
                                        </h3>
                                        <div
                                            class="decor"
                                            style="
                                                background-image: url(https://excelitai.com/wp-content/themes/naxly/assets/images/icons/decor-3.png);
                                            "
                                        ></div>
                                    </div>
                                    <div class="widget-content">
                                        <div class="text">
                                            <p>
                                                Our goal is to help our
                                                companies maintain achieve best
                                                class positions their respective
                                                industries &amp; our team works
                                                occur that pleasures have to be
                                                repudiated.
                                            </p>
                                        </div>
                                        <figure class="footer-logo">
                                            <a href="https://excelitai.com/"
                                                ><img
                                                    src="../../../assets/images/excelitai_qrcode.png"
                                                    alt="Awesome Image"
                                            /></a>
                                        </figure>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- footer part end -->

    <section class="copy-right">
        <div class="container py-3">
            <p class="text-center">
                Copyright 2021
                <router-link :to="{ name: 'Home' }">Excel IT AI </router-link>,
                All Rights Reserved.
            </p>
        </div>
    </section>
    <!-- end of copy right section  -->
</template>

<script>
export default {};
</script>

<style scoped>
@import "../css/footer.css";
.social-icons {
    text-align: left;
}
.social-icons ul {
    display: flex;
    justify-content: flex-start;
    align-content: center;
    padding-left: 0 !important;
}
.social-icons ul li {
    margin-left: 20px;
    background: linear-gradient(to bottom, #fff, rgb(223, 207, 207));
    /* padding: 0.5 1rem; */
    border-radius: 50%;
    width: 50px;
    height: 50px;
    text-align: center;
    padding-top: 0.2rem;
}
.social-icons ul li a {
    font-size: 2rem;
}
.social-icons ul #facebook a span {
    color: #0071f3 !important;
    text-decoration: none;
}
.social-icons ul #twitter a span {
    color: #1d9bf0 !important;
}
.social-icons ul #linkedin a span {
    color: #0072b1;
}

.social-icons ul #instagram a span {
    /* background: -webkit-linear-gradient(#535dca, #ba2f85) !important;
    -webkit-background-clip: text !important;
    -webkit-text-fill-color: transparent !important; */
    color: #dd2a7b;
}

.social-icons ul a:hover {
    text-decoration: none;
}
.footer-logo a img {
    width: 100px !important;
    height: 100px !important;
}
</style>
