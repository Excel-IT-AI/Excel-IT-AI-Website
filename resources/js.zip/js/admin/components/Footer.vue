<template>
  <footer class="footer">
    <div class="container-fluid">
      <div class="row">
        <div class="col-sm-6">{{ new Date().getFullYear() }} © Skote.</div>
        <div class="col-sm-6">
          <div class="text-sm-right d-none d-sm-block">
            Design & Develop by Themesbrand
          </div>
        </div>
      </div>
    </div>
  </footer>
</template>

<script>
export default {};
</script>
